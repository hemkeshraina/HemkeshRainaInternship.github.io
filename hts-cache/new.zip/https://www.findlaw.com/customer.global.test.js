<!DOCTYPE HTML>
<html lang="en-US">
    <head>
    
    
    
    <meta charset="UTF-8"/>
    

    <meta name="description" content="Find a local lawyer and free legal information at FindLaw.com"/>
    <meta http-equiv="x-ua-compatible" content="ie=edge"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>

    
<meta property="og:image" content="https://www.findlawimages.com/public/thumbnails_62x62/findlaw_62x62.png"/>
<meta property="og:type" content="website"/>
<meta property="og:site_name" content="Findlaw"/>
<meta property="og:title" content="404 Error: Page not found"/>
<meta property="og:url" content="https://lp.findlaw.com/content/errors-latl/404.html"/>
<meta property="og:description" content="Find a local lawyer and free legal information at FindLaw.com"/>

    
    


    <title>404 Error: Page not found</title>

    
        <meta name="robots" content="noindex, nofollow"/>
    
    

    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700&display=swap"/>
    <link rel="apple-touch-icon" sizes="180x180" href="https://www.findlawimages.com/latl/apple-touch-icon.png"/>
    <link rel="icon" type="image/png" href="https://www.findlawimages.com/latl/favicon-32x32.png" sizes="32x32"/>
    <link rel="icon" type="image/png" href="https://www.findlawimages.com/latl/favicon-16x16.png" sizes="16x16"/>
    <link rel="mask-icon" href="https://www.findlawimages.com/latl/safari-pinned-tab.svg" color="#eb7a3b"/>
    <link rel="stylesheet" href="https://www.findlawimages.com/etc/designs/flcommon/flfe/css/flpublic.redesign.css"/>
    
    <script>
    /* Thu, 03 Jun 2020 */ ! function(a, b, c, d, e) {
        if (b.search.match(/[\?&]opDMH\=off/i) || c.cookie.match(/(^|;)\s*opDMH\=off/)) return !1;
        var f, g, h, i, j, k = 'https://secure.marketinghub.opentext.com/es/' + e + '/c/HQmX7t5GzUy2gvKqxVjtbcpU0KXRBTrkHHT3XsI7oI/u/customer.global.js',
            l = [],
            m = b.search.match(/[\?&]dmhTest\=([^\?&#]+)/i) || c.cookie.match(/(^|;)\s*dmhTest\=([^;]+)/),
            n = !!m || b.search.match(/[\?&]opnocache\=([^\?&#]+)/i) || c.cookie.match(/(^|;)\s*opnocache\=([^;]+)/);
        for (m && (k = k.replace('customer.global.js', 'customer.global.test.js')), n && (k = k.replace('/es/', '/esnocache/')), h = b.search.match(/[\?&](dmhBuster\=\w+)/i) || c.cookie.match(/(^|;)\s*(dmhBuster\=\w+)/), h && (k = k + '?' + h[1]), a._dmhConfig = a._dmhConfig || {}, d && (a._dmhConfig.loadAsync = !0), l = [k], i = 0; i < l.length; ++i) j = l[i], 'https:' === b.protocol && (j = j.replace(/^http\:\/\/by/, 'https://secure')), f = c.createElement('script'), f.src = j, d ? (g = c.getElementsByTagName('script')[0], g.parentNode.insertBefore(f, g)) : c.write(f.outerHTML + '\n');
        return !0
    }(window, location, document, !0, 1765);
</script>

    
    <!-- Channel Attribution Project : Sitecatalyst logic -->

    <script>
        var FL = FL || {};
        FL = {
            local: {
                hasLocation: true,
                hosts: {
                    lawyers: "lawyers-dev.findlaw.com"
                }
            }
        };
		var FLDataLayer =
	        {
	                "pageLevel" :  "No SiteCatalyst for This page",
	                "pageTitle" :  "404 Error: Page not found",
	                "pageType"  :  "index",
	    			"pageVersion" : "redesign2017",
	    			"pagePracticeCode" : "", 
	    			"pagePracticeName" : ""
	        };
	
		if (FLDataLayer.pageType==="article"){
	        FLDataLayer.article = { 
				"id" : "404",
				"author" : "admin",
				"publishDate" : "September 18, 2018",
				"contentType" : "Blog"
			};
		}
    </script>
    <script id="at-hide">!function(e,t,n,i){function o(){return t.getElementsByTagName("head")[0]}!function(e,n,i){if(e){var o=t.createElement("style");o.id=n,o.innerHTML=i,e.appendChild(o)}}(o(),"at-body-style","body {opacity: 0 !important}"),setTimeout(function(){!function(e,n){if(e){var i=t.getElementById(n);i&&e.removeChild(i)}}(o(),"at-body-style")},3000)}(window,document);</script>

<script>
    var FLDataLayer = FLDataLayer || window.FLDataLayer || {};
    FLDataLayer.geo = FLDataLayer.geo || {};
    FLDataLayer.geo.cf_location = {"latitude":"28.57880","longitude":"77.33210","city":"Noida","region":"Uttar Pradesh"};
    FLDataLayer.visitor = FLDataLayer.visitor || {};
    FLDataLayer.visitor.botType = 0;
    FLDataLayer.visitor.ip = '122.177.45.14';
    FLDataLayer.pageViewId = '5b86e003d423df67';
</script>
<script src="https://www.findlaw.com/tag-manager/a0c0d582e2e6/cb2fdb5fc6f7/launch-23010cdf8f32.min.js" async></script>
    <script>window.setSearchLocationAutomatically=function()
        {return true;};
    </script>



    
    <!-- please don't forget to add this script while overriding head_ex.html -->
<script type="text/javascript" src="https://s7.addthis.com/js/300/addthis_widget.js#pubid=ra-5b637a7245af4b77"></script>

    <link rel="search" type="application/opensearchdescription+xml" title="LATL Search" href="https://files.findlaw.com/latl/opensearch.xml"/>






    
    
    

    
    

</head>
    <body>
        
    

    




    
    

    

    
        
    
        <div class="upper-banner">
            <div class="row">
                <p class="upper-banner-text">Are you a legal professional? <a href="https://lp.findlaw.com/" class="upper-banner-link">Visit our professional site <span class="upper-banner-link-icon" aria-hidden="true">&#187;</span></a></p>
            </div>
        </div>
    
    <div id="navbar-container">
        <div class="nav-main new-header-design">
            
    <input type="checkbox" id="mobile-nav-checkbox"/>
<label for="mobile-nav-checkbox" id="mobile-nav-toggle">
    <span aria-label="open/close mobile menu" role="button" tabindex="0">
    <span aria-hidden="true">
    </span>
  </span>
</label>
<div class="nav-overlay"></div>
<nav class="nav-mobile">
    <div class="top-nav-info">
        <a href="https://www.findlaw.com/" class="logoMargin"><img class="logo" src="https://www.findlawimages.com/latl/findlaw-new.png" alt="FindLaw home"/></a>
        <a class="button large alert uppercase expanded" href="https://lawyers.findlaw.com">Find your Lawyer</a>
        <span class="small-gray-font">Explore Resources For...</span>
    </div>
    <div class="nav-scrollable">
        <div class="accordion" data-accordion data-allow-all-closed="true">
            <div class="accordion-item" data-accordion-item>
                <div class="subcontainer">
                    <div data-link="https://public.findlaw.com/" class="accordion-link">Learn About the Law</div>
                    <a href="#" class="accordion-title primary-link" style="border-bottom: none;" aria-label="show/hide sub-topics">
                        <span aria-hidden="true"></span>
                    </a>
                </div>
                <div class="accordion-content" data-tab-content>
                    <ul>
                        <li><a href="https://injury.findlaw.com/">Accidents and Injuries</a></li>
                        <li><a href="https://www.findlaw.com/adr.html">Arbitration and Mediation</a></li>
                        <li><a href="https://bankruptcy.findlaw.com/">Bankruptcy</a></li>
                        <li><a href="https://public.findlaw.com/cannabis-law.html">Cannabis Law</a></li>
                        <li><a href="https://injury.findlaw.com/car-accidents.html">Car Accidents</a></li>
                        <li><a href="https://civilrights.findlaw.com/">Civil Rights</a></li>
                        <li><a href="https://consumer.findlaw.com/">Consumer Protection</a></li>
                        <li><a href="https://criminal.findlaw.com/">Criminal Law</a></li>
                        <li><a href="https://dui.findlaw.com/">DUI Law</a></li>
                        <li><a href="https://education.findlaw.com/">Education Law</a></li>
                        <li><a href="https://elder.findlaw.com/">Elder Law</a></li>
                        <li><a href="https://employment.findlaw.com/">Employment Law</a></li>
                        <li><a href="https://estate.findlaw.com/">Estate Planning</a></li>
                        <li><a href="https://family.findlaw.com/">Family Law</a></li>
                        <li><a href="https://healthcare.findlaw.com/">Health Care Law</a></li>
                        <li><a href="https://immigration.findlaw.com/">Immigration Law</a></li>
                        <li><a href="https://litigation.findlaw.com/">Litigation and Appeals</a></li>
                        <li><a href="https://military.findlaw.com/">Military Law</a></li>
                        <li><a href="https://injury.findlaw.com/product-liability.html">Product Liability</a></li>
                        <li><a href="https://realestate.findlaw.com/">Real Estate Law</a></li>
                        <li><a href="https://smallbusiness.findlaw.com/">Small Business Law</a></li>
                        <li><a href="https://socialsecurity.findlaw.com/">Social Security and Retirement Planning</a></li>
                        <li><a href="https://tax.findlaw.com/">Tax Law</a></li>
                        <li><a href="https://traffic.findlaw.com/">Traffic Laws</a></li>
                        <li><a href="https://www.findlaw.com/voting.html">Voting</a></li>
                    </ul>
                </div>
            </div>
            <div class="accordion-item" data-accordion-item>
                <div class="subcontainer">
                    <div data-link="https://statelaws.findlaw.com/" class="accordion-link">State Laws</div>
                    <a href="#" class="accordion-title primary-link" style="border-bottom: none;" aria-label="show/hide sub-topics">
                        <span aria-hidden="true"></span>
                    </a>
                </div>
                <div class="accordion-content" data-tab-content>
                    <ul>
                        <li><a href="https://statelaws.findlaw.com/alabama-law.html">Alabama</a></li>
                        <li><a href="https://statelaws.findlaw.com/alaska-law.html">Alaska</a></li>
                        <li><a href="https://statelaws.findlaw.com/arizona-law.html">Arizona</a></li>
                        <li><a href="https://statelaws.findlaw.com/arkansas-law.html">Arkansas</a></li>
                        <li><a href="https://statelaws.findlaw.com/california-law.html">California</a></li>
                        <li><a href="https://statelaws.findlaw.com/colorado-law.html">Colorado</a></li>
                        <li><a href="https://statelaws.findlaw.com/connecticut-law.html">Connecticut</a></li>
                        <li><a href="https://statelaws.findlaw.com/dc-law.html">District of Columbia</a></li>
                        <li><a href="https://statelaws.findlaw.com/delaware-law.html">Delaware</a></li>
                        <li><a href="https://statelaws.findlaw.com/florida-law.html">Florida</a></li>
                        <li><a href="https://statelaws.findlaw.com/georgia-law.html">Georgia</a></li>
                        <li><a href="https://statelaws.findlaw.com/hawaii-law.html">Hawaii</a></li>
                        <li><a href="https://statelaws.findlaw.com/idaho-law.html">Idaho</a></li>
                        <li><a href="https://statelaws.findlaw.com/illinois-law.html">Illinois</a></li>
                        <li><a href="https://statelaws.findlaw.com/indiana-law.html">Indiana</a></li>
                        <li><a href="https://statelaws.findlaw.com/iowa-law.html">Iowa</a></li>
                        <li><a href="https://statelaws.findlaw.com/kansas-law.html">Kansas</a></li>
                        <li><a href="https://statelaws.findlaw.com/kentucky-law.html">Kentucky</a></li>
                        <li><a href="https://statelaws.findlaw.com/louisiana-law.html">Louisiana</a></li>
                        <li><a href="https://statelaws.findlaw.com/maine-law.html">Maine</a></li>
                        <li><a href="https://statelaws.findlaw.com/maryland-law.html">Maryland</a></li>
                        <li><a href="https://statelaws.findlaw.com/massachusetts-law.html">Massachusetts</a></li>
                        <li><a href="https://statelaws.findlaw.com/michigan-law.html">Michigan</a></li>
                        <li><a href="https://statelaws.findlaw.com/minnesota-law.html">Minnesota</a></li>
                        <li><a href="https://statelaws.findlaw.com/mississippi-law.html">Mississippi</a></li>
                        <li><a href="https://statelaws.findlaw.com/missouri-law.html">Missouri</a></li>
                        <li><a href="https://statelaws.findlaw.com/montana-law.html">Montana</a></li>
                        <li><a href="https://statelaws.findlaw.com/nebraska-law.html">Nebraska</a></li>
                        <li><a href="https://statelaws.findlaw.com/nevada-law.html">Nevada</a></li>
                        <li><a href="https://statelaws.findlaw.com/new-hampshire-law.html">New Hampshire</a></li>
                        <li><a href="https://statelaws.findlaw.com/new-jersey-law.html">New Jersey</a></li>
                        <li><a href="https://statelaws.findlaw.com/new-mexico-law.html">New Mexico</a></li>
                        <li><a href="https://statelaws.findlaw.com/new-york-law.html">New York</a></li>
                        <li><a href="https://statelaws.findlaw.com/north-carolina-law.html">North Carolina</a></li>
                        <li><a href="https://statelaws.findlaw.com/north-dakota-law.html">North Dakota</a></li>
                        <li><a href="https://statelaws.findlaw.com/ohio-law.html">Ohio</a></li>
                        <li><a href="https://statelaws.findlaw.com/oklahoma-law.html">Oklahoma</a></li>
                        <li><a href="https://statelaws.findlaw.com/oregon-law.html">Oregon</a></li>
                        <li><a href="https://statelaws.findlaw.com/pennsylvania-law.html">Pennsylvania</a></li>
                        <li><a href="https://statelaws.findlaw.com/rhode-island-law.html">Rhode Island</a></li>
                        <li><a href="https://statelaws.findlaw.com/south-carolina-law.html">South Carolina</a></li>
                        <li><a href="https://statelaws.findlaw.com/south-dakota-law.html">South Dakota</a></li>
                        <li><a href="https://statelaws.findlaw.com/tennessee-law.html">Tennessee</a></li>
                        <li><a href="https://statelaws.findlaw.com/texas-law.html">Texas</a></li>
                        <li><a href="https://statelaws.findlaw.com/utah-law.html">Utah</a></li>
                        <li><a href="https://statelaws.findlaw.com/vermont-law.html">Vermont</a></li>
                        <li><a href="https://statelaws.findlaw.com/virginia-law.html">Virginia</a></li>
                        <li><a href="https://statelaws.findlaw.com/washington-law.html">Washington</a></li>
                        <li><a href="https://statelaws.findlaw.com/west-virginia-law.html">West Virginia</a></li>
                        <li><a href="https://statelaws.findlaw.com/wisconsin-law.html">Wisconsin</a></li>
                        <li><a href="https://statelaws.findlaw.com/wyoming-law.html">Wyoming</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="primary-link">
            <a href="https://www.findlaw.com/legalblogs.html">Blogs</a>
        </div>
        <div class="bottom-nav-info">
            <span class="small-gray-font">Are you a Legal Professional?</span>
            <div class="float-left"><i class="fa fa-gavel" aria-hidden="true"></i></div>
            <span class="bold"><a href="https://lp.findlaw.com/">Visit Legal Professionals Site</a></span>
        </div>
    </div>
</nav>



            <div class="row ">
                
    <div class="small-6 large-2 columns logo-wrapper">
    <a href="https://www.findlaw.com/" class="logoMargin">
        <img class="logoAEM" src="https://www.findlawimages.com/latl/findlaw-new.png" alt="FindLaw home"/>
    </a>
</div>



                
    <nav class="large-8 large-pull-2 columns" id="webMenu">
  <ul class="menu primary-nav">
    <li><a class="secondary-link" href="https://lawyers.findlaw.com">Find a Lawyer</a></li>
    <li><a id="item-lal" class=" secondary-link" href="https://public.findlaw.com/">Learn About the Law</a></li>
    <li><a class=" secondary-link" href="https://statelaws.findlaw.com/">State Laws</a></li>
    <li><a id="item-blog" class=" secondary-link" href="https://www.findlaw.com/legalblogs.html">Blogs</a></li>
  </ul>
</nav>



                <div class="small-6 large-2 large-push-8 columns secondary-nav-wrapper">
                    
                    <div class="mobile-menu-buttons isAEM">
                        <span class="search-test-icon active">
                          <span>Search</span> </span>
                        <span class="search-test-close"></span>
                    </div>
                    
                    <ul class="secondary-nav menu float-right">
                        <li>
                            <div id="cludo-search-instructions" class="screen-reader-text">Begin typing to search, use arrow keys to navigate, use enter to select</div>
                            <form id="cludo-search-form" class="search-form">
                                

                                
                                <span class="mobile-view-components search-test-clear lawyer"></span>
                                <label>
                                    <span id="cludo-search-label" class="mobile-view-components lawyer-text">Search for legal topics on FindLaw</span>
                                    <input id="searchbar" aria-autocomplete="list" aria-describedby="cludo-search-instructions" aria-controls="search_autocomplete" aria-haspopup="listbox" aria-expanded="false" type="search" maxlength="50" autocomplete="off" name="entry" class="search-field2" placeholder="Search legal topics" aria-label="search"/>
                                </label>
                                    <input type="submit" class="search-submit font-awesome" value="Research Your Legal Issue  &#xf105"/>
                                
                            </form>
                        </li>
                    </ul>
                </div>
                
            </div>
        </div>
    </div>

    
    <section class="search-secondary">
	
    <div class="hero-content row">
        <div class="medium-10 large-9 large-centered medium-centered columns">
             <div>
                
                <div class="search-mobile-input hide-for-medium">
                    <input id="trigger-mobile-search" type="search" placeholder="Legal issue and location"/>
		    		
                </div>
                <div class="search-desktop show-for-medium">
                    <form class="form-search-aem" action="https://lawyers.findlaw.com/lawyer/lawyer_dir/search/jsp/stdSearch_process.jsp">
                        <div class="input-group search-component main-page">
                            <input type="hidden" name="stype" value="BY_ADDR_OR_ZIP"/>

                            
                                <div class="search-parent">
                                <span class="mobile-view-components legal-text active">Search for legal issues</span>
                                <span class="mobile-view-components search-test-clear legal-issue active"></span>
                           
                            <input class="input-group-field law-search" id="legal_issue" name="keyword" type="search" autocomplete="off" data-target="autocomplete" data-title=".search-title" placeholder="Legal issue" data-law-handler/>
                                </div>
                            
                            
                            

                            
                                <div class="location-parent">
                                    <span class="mobile-view-components location-text active">For help near<span class="secondary-text"> (city, ZIP code or county)</span></span>
                                    <span class="mobile-view-components search-test-clear location active"></span>
                                    <input data-toggle="autocomplete-location" data-auto-focus="true" name="location" class="input-group-field location-search" type="text" placeholder="City, ZIP code, or county" id="autocomplete-location"/>
                                </div>
                            

                            

                            <div class="input-group-button submit-container">
                                
                                    
                                    <div class="error-message-mobile">Please enter a legal issue and/or a location</div>

                                    <input type="submit" class="button findlaw-submit font-awesome" value="Find Your Lawyer  &#xf105"/>
                                

                                
                            </div>
                        </div>
                    </form>
                    <div class="search-autocomplete" id="autocomplete" data-toggler=".is-active" aria-expanded="false">
                        <h5 class="search-title"></h5>
                        <ul class="search-menu" data-law-container></ul>
                        <div id="popular-directory-searches">
                            <h5>Popular Directory Searches</h5>
                            <ul id="popular-directory-searches-list" class="search-menu"></ul>
                        </div>
                        <h5>More Options</h5>
                        <ul class="search-menu more-options">
                            
                            
                                <li><a href="https://lawyers.findlaw.com/lawyer/lawyer_dir/search/jsp/name_search.jsp">Name
                                    Search</a></li>
                                <li><a href="https://lawyers.findlaw.com/lawyer/practice.jsp">Browse Legal Issues</a></li>
                                <li><a href="https://lawyers.findlaw.com/profile/profiles/lawfirm/a/1.html">Browse Law Firms</a></li>
                                <li><a href="https://lawyers.findlaw.com/lawyer/lawyer_dir/search/jsp/help.jsp">Support</a></li>
                          
                        </ul>
                    </div>
                </div>
             </div>
        </div>
    </div>
    <div class="mobile-search" id="mobile-search">
        <div class="search-autocomplete-container">
            <form action="https://lawyers.findlaw.com/lawyer/lawyer_dir/search/jsp/stdSearch_process.jsp">
                <input type="hidden" name="stype" value="BY_ADDR_OR_ZIP"/>
                <input class="law-search" name="keyword" type="search" autocomplete="off" data-target="autocomplete-mobile" data-title=".search-title-mobile" placeholder="What&#39;s your legal issue?" data-law-handler-mobile/>
                <div class="search-autocomplete" id="autocomplete-mobile">
                    <h5 class="search-title-mobile"></h5>
                    <ul class="search-menu" data-law-mobile-container></ul>
                    <div id="popular-directory-searches-mobile">
                        <h5>Popular Directory Searches</h5>
                        <ul id="popular-directory-searches-mobile-list" class="search-menu"></ul>
                    </div>
                </div>
                <input type="search" name="location" placeholder="Location" id="autocomplete-location-mobile"/>
                <div class="input-group-button">
                    <input type="submit" class="button" value="Search"/>
                    <button class="button cancel-search">Cancel</button>
                </div>
            </form>
        </div>

        <div class="search-autocomplete-legal-issue-mobile" id="autocomplete-mobile">
            <h5>More Options</h5>
            <ul class="search-menu">
                <li><a href="https://lawyers.findlaw.com/lawyer/practice.jsp">Legal Issues</a></li>
                <li><a href="https://lawyers.findlaw.com/lawyer/lawyer_dir/search/jsp/name_search.jsp">Name Search</a></li>
                <li><a href="https://lawyers.findlaw.com/profile/profiles/lawyer/a/1.html">Browse Lawyers</a></li>
                <li><a href="https://lawyers.findlaw.com/profile/profiles/lawfirm/a/1.html">Browse Law Firms</a></li>
                <li><a href="https://lawyers.findlaw.com/lawyer/lawyer_dir/search/jsp/help.jsp">Help</a></li>
            </ul>
        </div>
    </div>
</section>




    



    
    <main id="main-content">
    
    <div class="latl-pages">
    <!-- main -->
    <section class="row" id="latl-content">
        
    
    
    
    <div class="section"><div class="new"></div>
</div><div class="iparys_inherited"><div class="topbanner iparsys parsys"></div>
</div>



    <div class="medium-10 medium-centered large-9 large-uncentered columns">
        <!-- breadcrumbs -->
        
    <div class="row">
    <nav aria-label="breadcrumbs" class="breadcrumbs-container">
        <ul class="breadcrumbs">
            
                
                
                    <li class="breadcrumb"><a href="https://www.findlaw.com/">FindLaw</a></li>
                
            
                
                    <li class="breadcrumb">404 Error: Page Not Found</li>
                
                
            
        </ul>
    </nav>
</div>


        
    
    <div class="section"><div class="new"></div>
</div><div class="iparys_inherited"><div class="dartAd_top iparsys parsys"></div>
</div>


        <div class="richtext parbase section">
    
<div class="row">
 <h1>404 Error: Page Not Found</h1>
    <p>Wait, don't call your lawyer! The page you were trying to retrieve does not exist on this server, but we can still help you.</p>
    <p>Try searching again, or take a look below for more solutions.</p>
    <h3>Popular Legal Issues</h3>
    <ul class="default">
        <li><a href="https://injury.findlaw.com/">Accidents & Injuries</a></li>
        <li><a href="https://criminal.findlaw.com/">Criminal Law</a></li>
        <li><a href="https://dui.findlaw.com/">DUI</a></li>
        <li><a href="https://employment.findlaw.com/">Employee Rights</a></li>
        <li><a href="https://family.findlaw.com/">Family Law</a></li>
        <li><a href="https://realestate.findlaw.com/">Real Estate</a></li>
        <li><a href="https://smallbusiness.findlaw.com/">Business</a></li>
    </ul>
</div>

</div>


    </div>
    <div class="medium-10 medium-centered large-3 large-uncentered columns">
        <div class="side">
            
    
    <div class="section"><div class="new"></div>
</div><div class="iparys_inherited"><div class="rightpar iparsys parsys"></div>
</div>


        </div>
    </div>



    </section>
</div>






    </main>
    
    
	<footer class="footer footer-alternate"> <a class="back-to-top" href="#"><span class="back-to-top-icon fa fa-arrow-circle-up" aria-hidden="true"></span>Back to Top</a>
	  <div class="footer-upper">
		<div class="row">
		  <div class="footer-col-1">
			<nav class="footer-nav">
			  <ul class="footer-nav-list">
				<li class="footer-nav-section"> 
				  <span class="footer-nav-title">
					<a href="https://www.findlaw.com/company.html">About Us</a> 
					<button id="footer-nav-toggle-1" aria-label="show/hide About Us section" class="footer-nav-toggle" data-controls="footer-nav-sublist-1"><span class="footer-nav-icon fa fa-angle-right" aria-hidden="true"></span></button>
				  </span>
				  <ul id="footer-nav-sublist-1" class="footer-nav-sublist">
					<li><a href="https://www.findlaw.com/company/contact-us/contacts.html">Contact Us</a></li>
					<li><a href="https://www.findlaw.com/company/privacy/privacy-statement.html">Privacy</a></li>
					<li><a href="https://www.findlaw.com/company/findlaw-terms-of-service.html">Terms</a></li>
					<li><a href="https://www.findlaw.com/company/disclaimer.html">Disclaimer</a></li>
				    <li><a rel="nofollow" id="_bapw-link" href="#" target="_blank" title="Cookies">Cookies</a></li>
					  <li><a href="https://privacyportal-cdn.onetrust.com/dsarwebform/dbf5ae8a-0a6a-4f4b-b527-7f94d0de6bbc/5dc91c0f-f1b7-4b6e-9d42-76043adaf72d.html">Do Not Sell My Info</a></li>
					<li class="footer-badge-mbl-only"><a rel="nofollow noopener" href="https://accessible360.com" target="_blank" class="reviewed-by-accessible"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFAAAABQCAYAAACOEfKtAAAKQ2lDQ1BJQ0MgcHJvZmlsZQAAeNqdU3dYk/cWPt/3ZQ9WQtjwsZdsgQAiI6wIyBBZohCSAGGEEBJAxYWIClYUFRGcSFXEgtUKSJ2I4qAouGdBiohai1VcOO4f3Ke1fXrv7e371/u855zn/M55zw+AERImkeaiagA5UoU8Otgfj09IxMm9gAIVSOAEIBDmy8JnBcUAAPADeXh+dLA//AGvbwACAHDVLiQSx+H/g7pQJlcAIJEA4CIS5wsBkFIAyC5UyBQAyBgAsFOzZAoAlAAAbHl8QiIAqg0A7PRJPgUA2KmT3BcA2KIcqQgAjQEAmShHJAJAuwBgVYFSLALAwgCgrEAiLgTArgGAWbYyRwKAvQUAdo5YkA9AYACAmUIszAAgOAIAQx4TzQMgTAOgMNK/4KlfcIW4SAEAwMuVzZdL0jMUuJXQGnfy8ODiIeLCbLFCYRcpEGYJ5CKcl5sjE0jnA0zODAAAGvnRwf44P5Dn5uTh5mbnbO/0xaL+a/BvIj4h8d/+vIwCBAAQTs/v2l/l5dYDcMcBsHW/a6lbANpWAGjf+V0z2wmgWgrQevmLeTj8QB6eoVDIPB0cCgsL7SViob0w44s+/zPhb+CLfvb8QB7+23rwAHGaQJmtwKOD/XFhbnauUo7nywRCMW735yP+x4V//Y4p0eI0sVwsFYrxWIm4UCJNx3m5UpFEIcmV4hLpfzLxH5b9CZN3DQCshk/ATrYHtctswH7uAQKLDljSdgBAfvMtjBoLkQAQZzQyefcAAJO/+Y9AKwEAzZek4wAAvOgYXKiUF0zGCAAARKCBKrBBBwzBFKzADpzBHbzAFwJhBkRADCTAPBBCBuSAHAqhGJZBGVTAOtgEtbADGqARmuEQtMExOA3n4BJcgetwFwZgGJ7CGLyGCQRByAgTYSE6iBFijtgizggXmY4EImFINJKApCDpiBRRIsXIcqQCqUJqkV1II/ItchQ5jVxA+pDbyCAyivyKvEcxlIGyUQPUAnVAuagfGorGoHPRdDQPXYCWomvRGrQePYC2oqfRS+h1dAB9io5jgNExDmaM2WFcjIdFYIlYGibHFmPlWDVWjzVjHVg3dhUbwJ5h7wgkAouAE+wIXoQQwmyCkJBHWExYQ6gl7CO0EroIVwmDhDHCJyKTqE+0JXoS+cR4YjqxkFhGrCbuIR4hniVeJw4TX5NIJA7JkuROCiElkDJJC0lrSNtILaRTpD7SEGmcTCbrkG3J3uQIsoCsIJeRt5APkE+S+8nD5LcUOsWI4kwJoiRSpJQSSjVlP+UEpZ8yQpmgqlHNqZ7UCKqIOp9aSW2gdlAvU4epEzR1miXNmxZDy6Qto9XQmmlnafdoL+l0ugndgx5Fl9CX0mvoB+nn6YP0dwwNhg2Dx0hiKBlrGXsZpxi3GS+ZTKYF05eZyFQw1zIbmWeYD5hvVVgq9ip8FZHKEpU6lVaVfpXnqlRVc1U/1XmqC1SrVQ+rXlZ9pkZVs1DjqQnUFqvVqR1Vu6k2rs5Sd1KPUM9RX6O+X/2C+mMNsoaFRqCGSKNUY7fGGY0hFsYyZfFYQtZyVgPrLGuYTWJbsvnsTHYF+xt2L3tMU0NzqmasZpFmneZxzQEOxrHg8DnZnErOIc4NznstAy0/LbHWaq1mrX6tN9p62r7aYu1y7Rbt69rvdXCdQJ0snfU6bTr3dQm6NrpRuoW623XP6j7TY+t56Qn1yvUO6d3RR/Vt9KP1F+rv1u/RHzcwNAg2kBlsMThj8MyQY+hrmGm40fCE4agRy2i6kcRoo9FJoye4Ju6HZ+M1eBc+ZqxvHGKsNN5l3Gs8YWJpMtukxKTF5L4pzZRrmma60bTTdMzMyCzcrNisyeyOOdWca55hvtm82/yNhaVFnMVKizaLx5balnzLBZZNlvesmFY+VnlW9VbXrEnWXOss623WV2xQG1ebDJs6m8u2qK2brcR2m23fFOIUjynSKfVTbtox7PzsCuya7AbtOfZh9iX2bfbPHcwcEh3WO3Q7fHJ0dcx2bHC866ThNMOpxKnD6VdnG2ehc53zNRemS5DLEpd2lxdTbaeKp26fesuV5RruutK10/Wjm7ub3K3ZbdTdzD3Ffav7TS6bG8ldwz3vQfTw91jicczjnaebp8LzkOcvXnZeWV77vR5Ps5wmntYwbcjbxFvgvct7YDo+PWX6zukDPsY+Ap96n4e+pr4i3z2+I37Wfpl+B/ye+zv6y/2P+L/hefIW8U4FYAHBAeUBvYEagbMDawMfBJkEpQc1BY0FuwYvDD4VQgwJDVkfcpNvwBfyG/ljM9xnLJrRFcoInRVaG/owzCZMHtYRjobPCN8Qfm+m+UzpzLYIiOBHbIi4H2kZmRf5fRQpKjKqLupRtFN0cXT3LNas5Fn7Z72O8Y+pjLk722q2cnZnrGpsUmxj7Ju4gLiquIF4h/hF8ZcSdBMkCe2J5MTYxD2J43MC52yaM5zkmlSWdGOu5dyiuRfm6c7Lnnc8WTVZkHw4hZgSl7I/5YMgQlAvGE/lp25NHRPyhJuFT0W+oo2iUbG3uEo8kuadVpX2ON07fUP6aIZPRnXGMwlPUit5kRmSuSPzTVZE1t6sz9lx2S05lJyUnKNSDWmWtCvXMLcot09mKyuTDeR55m3KG5OHyvfkI/lz89sVbIVM0aO0Uq5QDhZML6greFsYW3i4SL1IWtQz32b+6vkjC4IWfL2QsFC4sLPYuHhZ8eAiv0W7FiOLUxd3LjFdUrpkeGnw0n3LaMuylv1Q4lhSVfJqedzyjlKD0qWlQyuCVzSVqZTJy26u9Fq5YxVhlWRV72qX1VtWfyoXlV+scKyorviwRrjm4ldOX9V89Xlt2treSrfK7etI66Trbqz3Wb+vSr1qQdXQhvANrRvxjeUbX21K3nShemr1js20zcrNAzVhNe1bzLas2/KhNqP2ep1/XctW/a2rt77ZJtrWv913e/MOgx0VO97vlOy8tSt4V2u9RX31btLugt2PGmIbur/mft24R3dPxZ6Pe6V7B/ZF7+tqdG9s3K+/v7IJbVI2jR5IOnDlm4Bv2pvtmne1cFoqDsJB5cEn36Z8e+NQ6KHOw9zDzd+Zf7f1COtIeSvSOr91rC2jbaA9ob3v6IyjnR1eHUe+t/9+7zHjY3XHNY9XnqCdKD3x+eSCk+OnZKeenU4/PdSZ3Hn3TPyZa11RXb1nQ8+ePxd07ky3X/fJ897nj13wvHD0Ivdi2yW3S609rj1HfnD94UivW2/rZffL7Vc8rnT0Tes70e/Tf/pqwNVz1/jXLl2feb3vxuwbt24m3Ry4Jbr1+Hb27Rd3Cu5M3F16j3iv/L7a/eoH+g/qf7T+sWXAbeD4YMBgz8NZD+8OCYee/pT/04fh0kfMR9UjRiONj50fHxsNGr3yZM6T4aeypxPPyn5W/3nrc6vn3/3i+0vPWPzY8Av5i8+/rnmp83Lvq6mvOscjxx+8znk98ab8rc7bfe+477rfx70fmSj8QP5Q89H6Y8en0E/3Pud8/vwv94Tz+4A5JREAAAAZdEVYdFNvZnR3YXJlAEFkb2JlIEltYWdlUmVhZHlxyWU8AAADE2lUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNS42LWMxMzggNzkuMTU5ODI0LCAyMDE2LzA5LzE0LTAxOjA5OjAxICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIiB4bWxuczpzdFJlZj0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlUmVmIyIgeG1wOkNyZWF0b3JUb29sPSJQaXhlbG1hdG9yIDMuNiIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDpBQkVCQUQzMkEwREIxMUU5QUE2NkZFNDg1MjBEQUM3RiIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDpBQkVCQUQzM0EwREIxMUU5QUE2NkZFNDg1MjBEQUM3RiI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ4bXAuaWlkOkFCRUJBRDMwQTBEQjExRTlBQTY2RkU0ODUyMERBQzdGIiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOkFCRUJBRDMxQTBEQjExRTlBQTY2RkU0ODUyMERBQzdGIi8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+K4Yw5QAAJiBJREFUeNrcXQd4VFW33QkkkAoJhJJQUuhIkw5BVECaoiAWREFBf0CqdLBTBJQmKr0FpFnoJVQJVZFOQCBAqKETID0kmbfWnrnjJExIAf3fe+f7DjOZuXPvOfvssnY5Bwd/f3/JTsvDf9LQHSwdzWQSccR7k53reUkavnDgG7yaHP7+XCyf46Uw/qqB/pSDScrh7wC8L45eEL0AuqPldnzEffS76Nfx0/N4PYl7HsfrIfx9zSQZnmMyP4xjdLA82PT30MUyLOtvjHFpx1NTJXstr/y7zR39WfS6mNgzeK2F7mqMPYvmiV6CxLZea37zAC8HQYEwvN+Hztdb/9aE/i0C1gdHdMZre/RCT/jeTlwQELOuhfPi8LICPQR9yz89Mcd/8t4Qi56Y2GG834PeLSviOTo4yoMHDyQuLs4sZpDz5KQk/YzvTWDblJQUfX1Ec0N/G30znn0SYxhm4fz/UwR8D4M/jdfv0as96sL4+Hi5Gx1tkUiTuLm5iVNeJyVaWlqaxIKYSSAiCUjC3rhxQ987OjoqIXndIwhaHv0r9DPo/UBM5//tBGwDGhxHn4spBdmVt7x5lWhnL5zXnhd/V6hUSb+7cOmiNG/ZSrbv2iGuIOSVK1dk9fr18slnn0nkxYtSqVJl2fLbNgkIDJQ7t28r4e7dvSvnLl6Qc7hXbEyMEtfBwSHjY4tiTJPQScjO/xsJyAEuQl+F95XsXWCIXgy4qFixYtLtgw9kw/oNEnn5knw3daokJCTIg9RUORNxWgKDgqRcuXLi6uoqwcENpcNbb0lKaop0+eB9adCwoZyPjFRieXp6ytrQUNm2dZv07tVb3PG3If6ZtJIY43z0tRbu/C8T0LzQbZXrRN6yy3FOTnL//n0VPYrklWtXpXmLljJ95kwpWLCgdH77benSqZPkyZNHShb3lZ07dkhMTKzUrFVLXmrTxvIcB6lVvYbUrVtP1q/bIGfOR0qSKU2exjXBjYIlX758Muqr0RL+119Sr0EDuX79usTGxkokuJIizntnaK2xluEY93vi8F8kICzeRAxkeUbjwAEnQEw5iWvXr0nTF16QVWvXSv78+XW8v+/dK8nJybJ0yRLx8SkiS3/5RaqBQHfvRsu9uFj5ccECef8//5HR48bJ4AGDwKnrJWTRInH3cJcZ4NZ8eZ30OS1btdbXPr16KfH79+unnJmS8kD8SpSQ7t17yE0s3NlzZ1VVZBBtIpC5IOICh/8CAfPhwavx+pG9L5OSk8QZXOFdqBC4KUYeJCVLsxeayctt2yl02/fH73Lw4CGZPOVb6QgOXLliuezetQuGIY94QGxJQF/f4lLCz1e+mThe9u7eA/1XUS5cuCChGzeIp7uH+ILw1apXk5MnT0roli2y//AhCd2wQcK2/yYJ4Lp3u3SRH6ZNlYNHj0rt2nUk4uwZyeNod7rvYFC7VQ39SwT0QCc0ecnel6nQY1z1uSEh8tkXXyjBflm5XLZs3iojvxolHi6uEv8gWa5fuya3b9+R5555RnaG7ZRfV62QZ59/XlIfpMjhw4fl/PkLsn//Ab1nRMRpfV3+y6+SjPvfvntH3uzYEXqyrPTp2UvKwahMnzpNggKDJBlqomLZctK7T2+ZO3uOREVFyd59f0jNp2tKFNRHJq0Beji6/z9LQAfxw79HQZUK6WQB4kGRpFW9igEn4H2pUqWlabNm4uKcT5wh0sMGD1ILPGDgIP3NmtWrpVAhb7kJsV28bJk4OznL9atXJb+Li3h5eUnbl16SLp07Sym/EhJx+rQ0fe55Wbl8uZTy9ZO80KuJiYlqpX9duVLWw5DE3I+R8OPH9N4LoRoSAX26wug0adoEvz8j88DVcVAr1MN2m0ndysMW1zL7JMmBL+xGYGpxp9I1YrWSJUtKT+iiTRs3ypKflsnHw4arYi9TOgBiDCMSfUcOHTos1SF2fsWLi3NeZ+ndr6+cpghC9C5cuSzFCvuoYeEkb928KY4gfCFvb0kmx16/oYR1d3cXE76/A+xIqPMiCN0VFt3bu5BUqVxRXnn5FVm4eJG0bt5S1m8K1fHt2rlLKlWuLL5FikixokUlT95HOmAJYJSK8IUvPBEONP0dADiQkXg0FneBw4jFCFNavfgiuGmpfPbpZzJvzhyJjr4rNWvXVmPinCevjIBIk4h+xf0k+s5tcOMAmTN7tnJvUGl/JQ6tJtWAFwhXoEABwJdU1Y3FQXQaIT4nDZaL3yUB+kydPk3q1Hxa6qITX9apV8+M5N/vKvVgtb8Z97U0BBT6euxYSYJxyYJ4bC6YKwMUXo/NgQa+z2sSLmXzjID4MkSIolqggKccO2YWn48GDpQRI0fg73ApWrSILFywUAYOGijlAgIVo1GMPEAoFxiLVBBDLMCXXEexJBFI0BQS0pRmRUt5QERConwgoht+6+TsbHX3SHASnqqEz2j83LMyBoQrU8aM5SdOmCjDhwyRouBA43eGJ3P+/HlxBycXwwLxHjbtSKqDVM+SgAFZEBCiOxlwpa8pA7Y7c+YMCFRULkMxTxw/QQaASMUhgldv3ZSagCQhPy6UyhCbrVu2Qhc2lUAQmkQi0UgEczjMBC6Nljv37+nffkWLia+fn1VUie8M4hJoE0/eunVLLl+6JNFQC0R3RYsUVfeP9yJR6Dufhzoo4OYh9erXkzt37sDiH1DRdYP15vN5XVJSolyCvn6n49ty9uxZvaZUyVLK4TY6/xeI8mtiEwZ7iIBBmRDQEhZrjjehpgxiS6DKz06BiHSpWjVvLhUrV5IT4cd1ALfxGSf+QbducgPXbt++XbmGnylGBDEuXY3S+1UqV16eefZZiFmwVK1WTfGbEs/ZyY7fnCD37t2Vs2cw4QMHZAdA966wMLkOdeACbEjiO1qgCrmZ6oVcyQUxOI7P50Jcw0L37PGhfD/1B7l9J1oKw6AVBIGLgEvJ0daYoYO8j5c5mXJgYOYc6A3OO2+BLemcf+qgQ0eOigeArYenhyxbslTavPwyMJyLKnMPDw8l5EVwgjtgix8mloZBJUNEzsN1c82XX158sbW0hM5s0bKlcod14bAyhh60tZicOLuTU3oddgTjCAXQXgegvnPPbnGBNS+BRSCxMgYZSMybME7k+BnTpst/uneTvr37qLXmor/84kviBSNGCUsXGHaQsrjTGYecEBAXrwSbvfyQiQL3cGAr1qyWKlWqytq1a6RZsxekfJky0qVrV+nz0UdSp0YNpQQhicF1lyB28QDYL7ZsLUOGD4WPG2y9531AEBLLThAgc/WC+zuBWG5uLvo3F3X+3HkyacIEuHQnpGihwmrRbUWS+tENi/7VV2Ok/euvKVe2wNipB08Ca77XqbMsXLhA/Es/RJMD4MRaObHCz2ckHlE8OYMcSL1VD9buZ+C3119/HZZunJQsVUrGfj1Olv/8s8TA6hKrcYDkpFPwAkoA5qxcsVLWrF+rxIuLS4CI3YNI3ldi5IR4hvGgy8bf8z5cgC5du8g+6LKRI0bqZ+p9YPGMe1Mf1oB+fv3NN2TQgIFSACL7y4oVErp5M3RjmkRGRooT0AKZxDG911ITvaspuxwI0Y2y5Cas4kMoQuJVqVoVeu0GiBKh302Z/K307ttH348eNVo++fQTKQ3w6wLuu3fvnly9eUPaw4WbNXeOckQS3Drex9HxyYciSUQvr4L6Pmx7mPwH+PD0mQhgUX+19lQjVwDWJ0yaJN17dJdKFSpIyMIfJSAwQBoFN5I70NcFMMaEhESIex6FTTZqJAVcSHZPSacW7Kx7B1vicfWSEpMk6sZ1CZkfIp06d4IeuSWvAMDugU/bB2DYBbqvQIGCSrwSsKQMQzH6chsKfwzEZeiwoXov4kIS7p8gngFNyHl8bfxsYzkafkzaQK9t2rJZgoACKBWF4Z/36t1LF/hUhJkJXnu1vbqLTvjdC9DJH/bsKW+0b6+GyNnZ2ZZWjG6PzNQKWwDzdbBqEVvFSxHs3/cjmTB5ovTt00cGDx4C5X1EWsMQVC5fQaHFfXBbYR8ftaA3wXW3YQFnzZylCjo1NU0t3z9FuKy4sWOHjrJ46WKFUjQQlIw4SFSn997T6M3qVasUm14EMggHkggMCoTXUlSRQ34L5LLQJxX/FAJ97j2EAy2wpTvEd5rtQGi1qtWoLjt27ZJvvv5GBg8ZLGtXr5XWL7VWotDh7wA9SKNBEaWok1tJvPdBPIoDVzIr4qViwt6WCWenkZsziT7bBDZwT2/zPdu90k5WrFohZQMC8BtHTRMQJTjhPVECA7sfdushP0yfChVUUi5GXZaCbu7wgHzVlbQaLwcZD6Ee5GBPB4J458Scm7W2KOiMZs2ayYJFi9SIbN2yRarXeFpmz5wh/v6lZfOmzRIWth2iUVhXneH1USNGyceffqzKODExGcRzyNIgkNN3YZGIMckNmaU5GB6rWKmi1KxZU9/nhBPr1qot+w7slwplyv7tdZg4xygJfuYZFXW2BSELxKdwYfkFBvFn9CKQLNshgAs9TXYIWBUEPPJQ3hNW6UrUFY3tfTN+vFowigAHcwoK2sOC8zjjkxD1l1q1ltXr1uZIbElAT+DJQQMHyfgJ48XVOZ+Y0uxTMCElWapUrCR/AEg7A2zHxsZlm4jnzp2TBvCPExLi1YMhQojEgn8Nt2/g4EEadKBqIqj39fWVbVu3giu7Ka61xYYgYBuMbk06EXY0R2ffszc5WuFr4MR78XES3KChLAF8KVHCD+IQqLqPlus6jAYfdBADKFLEx2owstvoT584cVIawf1iVo6GKbN441WMZcOmTeoi0mhkBwKZVMUUkDWr1kibV9pIQImSGu25AY+EkWuO/csvPteKhHzwuzl2H3gl9JMTLVlBGwLugBg3VoRC5M0IBLhvoSVJbXcF3SBW3gW95Oixo7LyVwZIN8u1a9fMfi0GR9doLoBs7Tq1Man7WYqtPeexePFisv/PP+XAoQNSCB6Nkb607RT1W3ejpSKMV6NnGqmKyAmErPxUZfkLhmI3EEQRiKmnh6fsgKsZunmTlPD1Ex+oIvrW7Eb5h50FKg1dOA+v93Sa4JPnNIyTxQqylwkMgtjEyPZt23Qy7ExHNgaOav9ae4tuMeXYaiYCKrE1B4xIszwvs3HkB4du/+031ZOuri7ZBt40aGyjxowRb8AuSg/HS/UUCKxIMTX8ZZ2bk9Oj4oBNHCzVA6R0/exOlCJEdi9arJg5sZ38AAjTJMM+/tgcXIVOyqlXITarXL9BA/EBpyclJmZ6LR3+Pbt3yx9/7FM9mEWlQjqcSJRQtmwZeatjR40c2XoqOUxINrISEM9vkqusHB58+eoVaQl/snmL5uplPA7WS8ZilC9fHrCphtwEtsxMNhnmik1MkHVr16QjfnZaSoo50vIO/F43qJ+E+IRcjRU0a6EETDOXkdXJ7aSZDG/eqpU10PA4jS4eXajmLVpIUmpKpo46dXI+oIO9u3ebQ8guLjladKqLOnVra1r0yrWoXHEgvTXwfSVyYG2xlP/ltDG6UbxwEWlhIWAuB/JQ48Qoxo9akMIwAOHHjsFy/6VinJNm3LctfPRH6dtstPokYLXc/ppi1iC4oZQvV9ZqBHKqAtTaWQivfjfUQOWnKpkrDOAFZZq4ANddv31LNoWGWo1LTnxmtupP15DiPkUkMZeSQ9rxThVyS8AUU5pO1IgA50yHmMtUycVG6Zotd9SqXVsepKVmqlN5tTPwGjN6ORVjwxgGBgZKmbJl1THInSKUCo4Yt39ufssB0GOoWrVqrsSXERvCiM8//VQtI/+2vc9zzzcRt3z5NceRmRZnTub3PXtl374/YVicc6hvEyR//nzyVJUqEpuUmEv6iQ+Xt1hufkyOY5UVS81y06i3WMHw/Xffycm/0uuxBykp0qBhA4DyOuopZNYYKbkXHyu/weXKqRgbcb6yUD+P0TxJQK/cErAQFDlBaG5CTWws4UjFOu7duzcdAeJi44HPHBVUs8ohM+7mfWj9Duzfb4U3OW1+fiXE2cEx84qFRzc3EjBX5a/MNdAA5MegDWyV3ebiYo6xbVi3Tl8PWgjwd+zNTMjGjRuLe34XgPXkzEF1YR/Zs2uXnIk4a71vThqTYPnSR55zNBUSMFeF5iyvoOuTB3gspzCAhPrrr5Pqg3pC95EAJ0+eVp1k6EFOqErValKxYkXNwWTW3OEVXblxXTasX5djMVZd7OaqBDRSmTkOgufKcc1ioPyORoERFnudbevmzZrPZViJLtVGizU1rqH1dXd3lVfatZP7CfGZijGflRfXhobmzhprwOIx8Cu5L82ehTXCWJkRihMkl6QByuRxSI/D6YifBIc9SHmgOVrez7gPv2MAYNfOnfidg64egwPr1q3VfAuvY/jICD+xCtXT1c1aumGPgIygHD5wUCIizqifmxNIRZ87CSrCNnSfE3XOETEi6Wl8wpoXDiDq+jWdHMPaHp6etskVc6bOUixO/eRimzcAUTiYO9G3pUe37hJx6pRUqFBBJ2/kfjlpVg34lyyl70nkE+Hh0giYkmqB1xkLxAg1S9/4/Mz0FLmdpXV//P67EtD4fXYaMWAy05gFC9qNPmVxnyR+G22LbBiS79e/v4bXu3bpIuUw+Xg8gAO8eOGCNS7HCfHhjDrbSgAfqgU+MABr1q6V55o0kfCTf8mx8GNaVMm6lsuXL5vvY6ldJlF5P8YXL168qEQLB0GPnjgur7/5ppb7XonK3Gc1PmeFQk6tMceUmJpiIZQ5tcAk2QXQgbqX1f+EW5lEbWL5q+u2zgkJcAaiwLK02XPmyE4C1QMHtAK03WuvKdfRApPLrkdd1YoDe2LFiHRQmSDNMzAZlRdiysS2Qh9vbx2QwVEGx7CGxQdWlWUWJO7IL0fIlO+/k7btX5V4gN3MOJDPKwYxplFiZWt2Y4RsTKabrJF3R51PterVZX7IQhk/ebLMmzsf7mqwnDl31h4BY6g/L9p+EljKXxYuCJFCHgW0BHfWjBny3ZQp0q1Hd1n60zJwSj5N5pBjbsfck5MnTjxkVIxIMonIEBXL2/bu26fcHIGBZFKrrCVs57HiAUFBEgYd+clnn5rHBLBetVJlLMDtR1rjS9euakF6dqyxofPCj4WrS8jGBWaB08Rvp2AhIjVcdur0Sfl+2jTp1Kmzji0DEW9xJifTpxdTVSfFJSfK+rXrpAYc7latWmpC5l3chGVhxH9G27dvn9U42DM05Nj792OlRo3qmhHrjHtcirpid1KXoi5rZOfwkSNamsbtDqybKVy4kDRp1kzuwuV7lE7i1Bgpz44Y0/W7dOmKnIJ6KWjRf0wVvNGhg6xasUI+/fwzCdu6TcaMHSu9enwo/4E+L13aP52BAi0jHLFORzKie3JYOTjZLHmgS8U8aoM6dSVk4QKFCYZB8fbwlF1hO7By0emImlE/mUxpSggq+/LUqZlYSX7Ogk9is7g4cz2zIbasfs1v2QKWmRgXLuAlhw8d0nLgR4FqgztPHA9XnevmZvbDmUyKBKMEP9NIY5F3Yu7r5xGnTyljcWNPmg1exF0OkYD7Mt6c9SzLl6/QTSzNmjTVLQqJiQlSPqhMOleMZbjHweKbQjeqIUlLy1xsmLa8ceOmzJs1GxMtqBzL1eRmGHMgNa/4FPQG16+FMblunZRhtRvAQnOrVzTELNNnAPachor4bdtvjxRjY+PNxtBQDdzSGdAIqa+vhMybpxnI/QcPyZDBg6Vvn7663Yw4lVW4Lpagh4WAf1AgqFgO2XIMY2QTx4+X4HoNZMu2raqg78OyssTjAibMKk9bq7R58yZrgOBRK84C9NORZ9WQ8D4s5X2387vK4VTmXt5eEhF5TvOx6XxjcCMNQ42aT2tqNStrvHGDWQ862UkK8Z4sP4mCAVzx668auDWew+upG99/7z1ZtHCh1K9fX5o2bSqzYQfGjR0jfiCwzbPvgHZHHS2yvMV2ECzgXrZkiVk/uHvoznOuxo8LFkqXru/LVZh+QhjqI5b1rlm1Ss6ePadcY89SGhNhKpSNC+GNRVm4eLHMmT9PC9OZpCL3mAmwwbIgzla/WzN2zVs8krP4eREvb9WDFy5csnJxRk1JGixZtFiLPb0siICLyTpBEpBqZAoscNu2beXlNi/JD999p+W/RtbOcpuNFEZHyy73venyHNAzZOdUrhas27aw7TJm3Dh5/a23ZMbsWVqqRvxHESTIvhl9R76BsrWddEagGxefIGGAGWztXmkrh48e1UQU43JaSQV99AZrbMS8h+TSxctWOGL2jU3SFKqkcrkKai0zaxwPa6T37tn9ELF5D6oSRr0XhMzXXVFGcTsDud9PnSrVa9RQKXgAvc1K2qCAQClVunQ61WVpO0yWpBJ9OSqN1IzuXPT9ezJ1+nRNRrdt87K4gjgfdu8h73TqJJ3ffVfBLa/zgz87f/58OX78hF0u5Ir/GBIi5y9dlBFffim/rlguPpbqBa48X2kJly5bJpMnTdYC8h9hsDLmX1ie8Xyzpvo9lXmqnW4o+T2WhJPtRkMmrJjwnzhhgi5Y8aLm1CyBe4+ePaVsuXKyZ+9eLTxfGLJAWsNwcTOPPZWBGW7TWbK0gz3I3//noNL+JqP7FS1mKupVyMS2ZPESZdQCrm4m86KaTFu3bNX3vLZcYBDPbTC1fKGFfpeclGyCZTbdvXvPBChiio2NNfXt3ce0dMlS8/fJD6zfG51/gzP0+xXLV5iGDhliguXW3/N7EFm/W7t2nT7X2cHR5Oqcz27Xsbq5mwCq9Tf8/e3b0fo+MvK8yS1/flMR70KmMv4BJv8SJU0waqZt237TOTdv9oIpLGyHaeDAgaZdO3ebWuBvuLMmW9qg7zfoZltc1MDBvOnOyoGXgdeOEGhC9hm59dFq9zwyG5aKGbEvv/xC/Ir7WleF7t6Y0WNk6PChqviNraYUU64+t3YR2xnBCns6jHqVYsaaF5agubr+zdEsMGfyihsTeQ8721jTcWydunV1gw5FlBBEg7RNm8nmrVukbGCQNcjB/S4zgQ4iAZ6564DxSZZ+DB44GNivtPTs3VM3Atmo0bexSov0bYbytqtGiJ8TZFVWzZq1tPr92NFweSa4obhjQveg/2jJXF1crG4QJ07Dcgvewi64f/UBhI36Z06UwDYneWMqc4q3LbFJSOJQI26YdfrSvHFHA7/4Deuix0+cIGX9A1Sv6IYeGCg+gwXxs+bOlQoVK8q40aNlx+5dMnbMOJk29QfZGRaGxbdG3pMhbvmNMGCegrZRCAdxwlCbGn8WhDVmMdG5c5EaeebKc2JcUaL2BHAZDUgKOIWWm4NginAJrOurr7YXXz9f5RjjsIicRrwzFp8bu5LImdnpDx6kKMEJqmfNmCXDPh4uJYoVt0R8UiU2Jk7rX0hgVtWqG4hncqcTa6aJLlatWqnJK6uUOOhxBmusY8qw0cYZXHjbZAnzG5x1AeadSLxs2XK6fdTTs4AMHjpEd2OeOROhTj83vgTBh+VvTuKzIKzyJogK/djcbGN43KbcCivOhV+44Efp1PkdxXyELWyETBx3cKNG0rpFCw1wMDR3AxJUzKeocix3ntKtFQuYtxzg4wv6WPfNZnQsyZ7DbHUSV5xbFLgnjl4AV29t6Hrp1ae33IPLR0u1c+8eza+ympWcwwrQs9AnwfUbyvHw46rTHhXPe9KNxZ202CTelG+nKPEKwfthAoxzImjnzoHOAMzc/EN1xPEx8FEUuJYcq+iCG3ZsoBBo860t8cQGxli7yXxUSaw9lH/t9i3p3bev5oJfh4jWq1tHnOGCpUBUtkFPaIAVA2KvEFRWd2TWrV1b5s2dp5iOkyIWe4xSiizTDJQY1kXzEYRcffv1hfHz1hJkLi5z0BUqVZS+H/WXV9u1kz27dstKuI88+OLriRN1nhy/XS9G5JOM9DLK26zdZKZ018wGSct2H5b05+W/qheSAq6a8M03+uASfn6qA6l/KPK0YAxdcQNM75691LJ6eRXQFU97gkQ0osdMAXD72YH9B6RxcLBMmzFdSgElMM7IyVGCGAn3hs89ZNBA+XP/n5p/Ibd1/7A71E2AfDRggHUfX7pnOMhwjDg2I70eIqBFS/2EN7vshYtYi+KJQbZu0VKTQSzznTNrljSC38iAAA/P0cMmIM68nsl3HgjBTX3cxTlr5kyFNF6YrJFgyi1HakIJzyTh2Fn6OwCcFYyx0BPhFltjZyjdx1LQ98w1HweI5kZvQpPp4LxGjYLh+VxSDmU+Ju/DezPP4ZMx9miVxztDLsDmp1sdMxwq4QaLxlB/5aeqyIhRI2HaC8tKOOTUH1TAFwF7enzYU909nuVy7OQJKejhqQdQFIIYXcPKcov+dnxHnEbd6uNTWC07lTbhjm0Cyp4aIcHIwbyev2MAgxzHHVOD+veX9RtDNcnEhaPy57jOXrygxeWMR9KiTps5w7xznXv44Pa92Kq1zJ49Ww4dOqQbs5lrNuKOFsPRjLovR5sNLT/uCKv8o8km28Z8ASf/NdwhTuiTYUOlCFy5M/AfG9RvINvg7zoCsObF4NpDx6xasVJF2TaTdwkuHQ+HgAejcb7nmzTRwkrut8tOcpyR8ksXL2plA8NfW7dulTv3IJpAByx74zMM6ESOatmqlcyD77tm9Rrp0a2bVrjexjyo56Lxu5YtWklp/9Ly7aSJgDTu6lZa88Qwqpj/2ExplNWZCcD6i0HEDrZEpLGgnmDxT0BAgEYxuFEm3lKkQ8J+/tln8gX83i8//0JGjPhS/GHFDVxnrC6TNtwOxpA6txX441605qVASBKCnOaAa0kI3eN79ZqG2k+fOqXJKZa3kSt84dNyV1FqBitPD4PFmqvWrNaNjm3btVViN2jQ0LpQVSpUgr97WYPIXEDbXA2P1Es1H9cnuSagEs18XsLTJjs6iGg+Ji5WlixdJtWrV9dIyU3oRjrkr7RtqzhpQUiIEp2GhUMr5lNEXSsSxrzrMkXBOSfBRbAulliOAzClWSMdDH26u3so+KV3Yxvip4EgdOFhFOQgju1ezH1ZvHiJJoZOnz6lC94SRC2NBWXVw2zoZN7LTqrgUpqDVDLZQSQ5IqBlC5ino3kX00OVRPR/+/XuK5OmTJYB/QfIRIgBXboL5y9K1WpVxB1cynMK2rZ7FdChH5T7Ho0tknOojzLzUDJumM4qz8tSk3zQ0XGWvImxQZubHrl4UXilL06QTL9+J1y1bdt+k5YvvCC+xYtZo9IW1WVKdZAyaWbj8ejajixLH8xEvI83PE/lIWeW4sNN1998/bVMgJ85dsxYPeul+wcfqNtEoMqE0Jz5c+ESnpW33nkb+jJSxZTcSgJGWk5yu3L5sjVIYD3eLjnZmovmd0x5UnyN09/oX1MnMw54ADqRR6AwUGpcT2NBkaxfp46GzY6EH1XiUbU0b9pEFzFvXqeMkKW2KRvEyxYBbVkavaGYzzL9O4AJPcVjTwYPGSL9+vSVIXDxmMnas+93FY1kiG3+fGZ9M3vmLCkJolKUGLCNT4hX3dajx4cSMm++KnuKoXFeIKu+Ei0FliQGlT7dxbbt28t38DCGDx2mxDYvwgUtxuwHKWDyKTHevLOegY8AuJVMp36M62kgur7XRb6AXqa1ZVVFBqvPgu8D2SVK+mBCVpQ2yTVw4lL0TmLZmGNESDxByI1bNsvvu/cqYGXSnZMrCn23c9dO3fE4e+4cSYGb9Ta4MAagmoGG0WPGyJcjR0gS3Kj+AwdoUDNk/jyJiY3TY+8mf/+9phkjYDyawlqvDd2g7mMhHx954803pFTpAFm06EdJgO6MPHtWOr7TEQt0Wt3LaKgSrwIFFBUUApg+Ag5lnpvVYKVLlgJGzGfrXpKKPEo0TByyX3GVm00d52m8xCabx0HQOhOW7N65Q1YD63FhzgN/ffL55xqJHjV6tAwfNlw3ZT/f+Fkt700EUV9tr6eKyCsvt5HWALncusBtXonJSVKmTBmpXq2qGaDjGdRnxJyfDP9YqsOdZGCD+V3WUgeBIMt++VmrKj4FAqhUqZKsWbVa/oqIAETx1227xI0E+fRxHRwdbIl3FkRjrfKfOa5vy6X3FAU9wUNfF2cMPDA5xI3XFCuesjbthx/UiBCydOjQQXUidR93OzEc+twzjbQcg4EI7nqfMHmSxhmNoCgnqffK7yLhR4/JUXTuOD8WHm61xrVq1NSsIdtQGCgaiePHj8tz0HEz4c6xXIP35ELwuRm8n1DM5WkxHz6Wq/K23PugDtIR1nknhjLN3vf0Bhjm4vZUYkIm6ocMGqwH3XAXZEu4g8yzBgT4S7f3P5DFS5coDhw56u9d9Q9SUjV2x1gjY488h4Z7e8sAjtwBGOZJILPnzpXqNarpkXjcrLgc3hG9k+++/VZioGdpzDx5jNTDFv9jcN5Xj0ODxzsG2Xyw1nRhVs8kE/DaJGN2j9aWRqZHzw/N7qBzPnXhKN6u0JvLfv5JN23vCAvT7xMBOf4uv8hvOYDHwRyTw7ujR47oNlcmtlpaNvgsA+GdoG+Ns7c6vPa6HhtVDAihmGVPXwbi7cfteIzcdpNJ5HFOsXxShxgcwSCaoveSDIdgay01JkbHnWcW8IwqfsatpSxHY1CCtS/9Bw6UUSNGyozp08Xfr4Sl/NbNIm5mkaPHQkLTUvft1w+YL0Y3eH87caKUxG/oibCqiycY8ewX49QNG3HlyWyfotdW4j2BiTvk9ih44xh1O0fBM8TSFx8OEfOZzpkGBthZc8iJk3uo4OnSceI8pIw+NIlx+OBBJTpLyRiCZ3EnMeP9+DitsKcLZvjZj5CVSRj3eLEERJ/UUfD/BAENAF4MC98PbzuKnTMHM+Y5WC5iHNZjPpXISQMXPFeVbpdRjEmMGA+DQe50cspyjxyl4SeMZRKIdOafOEv/nySg8Z8RMEjYFn++awGp/0ajQg3BIH5iwew/+Z8R/BsEtP1fFsriJRh/NxLzmQOBT4hgl3mOAe67A8/hsfPH/r/+bw4Rlj7P8t9hELzWUmBuknJiPvDHy6I7XW3ma7L44QR73Bl4E1+csvx3GPvx/rAp+3N+ou1/BBgAYiYw8UEO8CcAAAAASUVORK5CYII=" alt="Reviewed By Accessible360"/></a></li>
				  </ul>
				</li>
				<li class="footer-nav-section">
				  <span class="footer-nav-title">
					<a href="https://lawyers.findlaw.com/">Find a Lawyer</a>
					<button id="footer-nav-toggle-2" aria-label="show/hide Find a Lawyer section" class="footer-nav-toggle" data-controls="footer-nav-sublist-2"><span class="footer-nav-icon fa fa-angle-right" aria-hidden="true"></span></button>
				  </span>
				  <ul id="footer-nav-sublist-2" class="footer-nav-sublist">
					<li><a href="https://lawyers.findlaw.com/lawyer/state.jsp">By Location</a></li>
					<li><a href="https://lawyers.findlaw.com/lawyer/practice.jsp">By Legal Issue</a></li>
					<li><a href="https://lawyers.findlaw.com/profile/profiles/lawyer/a/1.html">By Lawyer Profiles</a></li>
					<li><a href="https://lawyers.findlaw.com/lawyer/lawyer_dir/search/jsp/name_search.jsp">By Name</a></li>
				  </ul>
				</li>
				<li class="footer-nav-section">
				  <span class="footer-nav-title">
					<a href="https://www.findlaw.com/company/consumer-resources.html">Consumer Resources</a>
					<button id="footer-nav-toggle-3" aria-label="show/hide Legal Consumer Resources section" class="footer-nav-toggle" data-controls="footer-nav-sublist-3"><span class="footer-nav-icon fa fa-angle-right" aria-hidden="true"></span></button>
				  </span>
				  <ul id="footer-nav-sublist-3" class="footer-nav-sublist">
					<li><a href="https://www.superlawyers.com/" target="_blank">Super Lawyers</a></li>
					<li><a href="https://www.abogado.com/" target="_blank">Abogado</a></li>
					<li><a href="https://www.lawinfo.com/" target="_blank">LawInfo</a></li>
				  </ul>
				</li>
				<li><span class="footer-nav-title"><a href="https://www.findlaw.com/company/resources-for-legal-professionals.html">Attorney Resources </a></span></li>
			  </ul>
			</nav>
		  </div>
		  <div class="footer-col-2">
			<a rel="nofollow noopener" href="https://accessible360.com" target="_blank" class="reviewed-by-accessible"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFAAAABQCAYAAACOEfKtAAAKQ2lDQ1BJQ0MgcHJvZmlsZQAAeNqdU3dYk/cWPt/3ZQ9WQtjwsZdsgQAiI6wIyBBZohCSAGGEEBJAxYWIClYUFRGcSFXEgtUKSJ2I4qAouGdBiohai1VcOO4f3Ke1fXrv7e371/u855zn/M55zw+AERImkeaiagA5UoU8Otgfj09IxMm9gAIVSOAEIBDmy8JnBcUAAPADeXh+dLA//AGvbwACAHDVLiQSx+H/g7pQJlcAIJEA4CIS5wsBkFIAyC5UyBQAyBgAsFOzZAoAlAAAbHl8QiIAqg0A7PRJPgUA2KmT3BcA2KIcqQgAjQEAmShHJAJAuwBgVYFSLALAwgCgrEAiLgTArgGAWbYyRwKAvQUAdo5YkA9AYACAmUIszAAgOAIAQx4TzQMgTAOgMNK/4KlfcIW4SAEAwMuVzZdL0jMUuJXQGnfy8ODiIeLCbLFCYRcpEGYJ5CKcl5sjE0jnA0zODAAAGvnRwf44P5Dn5uTh5mbnbO/0xaL+a/BvIj4h8d/+vIwCBAAQTs/v2l/l5dYDcMcBsHW/a6lbANpWAGjf+V0z2wmgWgrQevmLeTj8QB6eoVDIPB0cCgsL7SViob0w44s+/zPhb+CLfvb8QB7+23rwAHGaQJmtwKOD/XFhbnauUo7nywRCMW735yP+x4V//Y4p0eI0sVwsFYrxWIm4UCJNx3m5UpFEIcmV4hLpfzLxH5b9CZN3DQCshk/ATrYHtctswH7uAQKLDljSdgBAfvMtjBoLkQAQZzQyefcAAJO/+Y9AKwEAzZek4wAAvOgYXKiUF0zGCAAARKCBKrBBBwzBFKzADpzBHbzAFwJhBkRADCTAPBBCBuSAHAqhGJZBGVTAOtgEtbADGqARmuEQtMExOA3n4BJcgetwFwZgGJ7CGLyGCQRByAgTYSE6iBFijtgizggXmY4EImFINJKApCDpiBRRIsXIcqQCqUJqkV1II/ItchQ5jVxA+pDbyCAyivyKvEcxlIGyUQPUAnVAuagfGorGoHPRdDQPXYCWomvRGrQePYC2oqfRS+h1dAB9io5jgNExDmaM2WFcjIdFYIlYGibHFmPlWDVWjzVjHVg3dhUbwJ5h7wgkAouAE+wIXoQQwmyCkJBHWExYQ6gl7CO0EroIVwmDhDHCJyKTqE+0JXoS+cR4YjqxkFhGrCbuIR4hniVeJw4TX5NIJA7JkuROCiElkDJJC0lrSNtILaRTpD7SEGmcTCbrkG3J3uQIsoCsIJeRt5APkE+S+8nD5LcUOsWI4kwJoiRSpJQSSjVlP+UEpZ8yQpmgqlHNqZ7UCKqIOp9aSW2gdlAvU4epEzR1miXNmxZDy6Qto9XQmmlnafdoL+l0ugndgx5Fl9CX0mvoB+nn6YP0dwwNhg2Dx0hiKBlrGXsZpxi3GS+ZTKYF05eZyFQw1zIbmWeYD5hvVVgq9ip8FZHKEpU6lVaVfpXnqlRVc1U/1XmqC1SrVQ+rXlZ9pkZVs1DjqQnUFqvVqR1Vu6k2rs5Sd1KPUM9RX6O+X/2C+mMNsoaFRqCGSKNUY7fGGY0hFsYyZfFYQtZyVgPrLGuYTWJbsvnsTHYF+xt2L3tMU0NzqmasZpFmneZxzQEOxrHg8DnZnErOIc4NznstAy0/LbHWaq1mrX6tN9p62r7aYu1y7Rbt69rvdXCdQJ0snfU6bTr3dQm6NrpRuoW623XP6j7TY+t56Qn1yvUO6d3RR/Vt9KP1F+rv1u/RHzcwNAg2kBlsMThj8MyQY+hrmGm40fCE4agRy2i6kcRoo9FJoye4Ju6HZ+M1eBc+ZqxvHGKsNN5l3Gs8YWJpMtukxKTF5L4pzZRrmma60bTTdMzMyCzcrNisyeyOOdWca55hvtm82/yNhaVFnMVKizaLx5balnzLBZZNlvesmFY+VnlW9VbXrEnWXOss623WV2xQG1ebDJs6m8u2qK2brcR2m23fFOIUjynSKfVTbtox7PzsCuya7AbtOfZh9iX2bfbPHcwcEh3WO3Q7fHJ0dcx2bHC866ThNMOpxKnD6VdnG2ehc53zNRemS5DLEpd2lxdTbaeKp26fesuV5RruutK10/Wjm7ub3K3ZbdTdzD3Ffav7TS6bG8ldwz3vQfTw91jicczjnaebp8LzkOcvXnZeWV77vR5Ps5wmntYwbcjbxFvgvct7YDo+PWX6zukDPsY+Ap96n4e+pr4i3z2+I37Wfpl+B/ye+zv6y/2P+L/hefIW8U4FYAHBAeUBvYEagbMDawMfBJkEpQc1BY0FuwYvDD4VQgwJDVkfcpNvwBfyG/ljM9xnLJrRFcoInRVaG/owzCZMHtYRjobPCN8Qfm+m+UzpzLYIiOBHbIi4H2kZmRf5fRQpKjKqLupRtFN0cXT3LNas5Fn7Z72O8Y+pjLk722q2cnZnrGpsUmxj7Ju4gLiquIF4h/hF8ZcSdBMkCe2J5MTYxD2J43MC52yaM5zkmlSWdGOu5dyiuRfm6c7Lnnc8WTVZkHw4hZgSl7I/5YMgQlAvGE/lp25NHRPyhJuFT0W+oo2iUbG3uEo8kuadVpX2ON07fUP6aIZPRnXGMwlPUit5kRmSuSPzTVZE1t6sz9lx2S05lJyUnKNSDWmWtCvXMLcot09mKyuTDeR55m3KG5OHyvfkI/lz89sVbIVM0aO0Uq5QDhZML6greFsYW3i4SL1IWtQz32b+6vkjC4IWfL2QsFC4sLPYuHhZ8eAiv0W7FiOLUxd3LjFdUrpkeGnw0n3LaMuylv1Q4lhSVfJqedzyjlKD0qWlQyuCVzSVqZTJy26u9Fq5YxVhlWRV72qX1VtWfyoXlV+scKyorviwRrjm4ldOX9V89Xlt2treSrfK7etI66Trbqz3Wb+vSr1qQdXQhvANrRvxjeUbX21K3nShemr1js20zcrNAzVhNe1bzLas2/KhNqP2ep1/XctW/a2rt77ZJtrWv913e/MOgx0VO97vlOy8tSt4V2u9RX31btLugt2PGmIbur/mft24R3dPxZ6Pe6V7B/ZF7+tqdG9s3K+/v7IJbVI2jR5IOnDlm4Bv2pvtmne1cFoqDsJB5cEn36Z8e+NQ6KHOw9zDzd+Zf7f1COtIeSvSOr91rC2jbaA9ob3v6IyjnR1eHUe+t/9+7zHjY3XHNY9XnqCdKD3x+eSCk+OnZKeenU4/PdSZ3Hn3TPyZa11RXb1nQ8+ePxd07ky3X/fJ897nj13wvHD0Ivdi2yW3S609rj1HfnD94UivW2/rZffL7Vc8rnT0Tes70e/Tf/pqwNVz1/jXLl2feb3vxuwbt24m3Ry4Jbr1+Hb27Rd3Cu5M3F16j3iv/L7a/eoH+g/qf7T+sWXAbeD4YMBgz8NZD+8OCYee/pT/04fh0kfMR9UjRiONj50fHxsNGr3yZM6T4aeypxPPyn5W/3nrc6vn3/3i+0vPWPzY8Av5i8+/rnmp83Lvq6mvOscjxx+8znk98ab8rc7bfe+477rfx70fmSj8QP5Q89H6Y8en0E/3Pud8/vwv94Tz+4A5JREAAAAZdEVYdFNvZnR3YXJlAEFkb2JlIEltYWdlUmVhZHlxyWU8AAADE2lUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNS42LWMxMzggNzkuMTU5ODI0LCAyMDE2LzA5LzE0LTAxOjA5OjAxICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIiB4bWxuczpzdFJlZj0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlUmVmIyIgeG1wOkNyZWF0b3JUb29sPSJQaXhlbG1hdG9yIDMuNiIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDpBQkVCQUQzMkEwREIxMUU5QUE2NkZFNDg1MjBEQUM3RiIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDpBQkVCQUQzM0EwREIxMUU5QUE2NkZFNDg1MjBEQUM3RiI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ4bXAuaWlkOkFCRUJBRDMwQTBEQjExRTlBQTY2RkU0ODUyMERBQzdGIiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOkFCRUJBRDMxQTBEQjExRTlBQTY2RkU0ODUyMERBQzdGIi8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+K4Yw5QAAJiBJREFUeNrcXQd4VFW33QkkkAoJhJJQUuhIkw5BVECaoiAWREFBf0CqdLBTBJQmKr0FpFnoJVQJVZFOQCBAqKETID0kmbfWnrnjJExIAf3fe+f7DjOZuXPvOfvssnY5Bwd/f3/JTsvDf9LQHSwdzWQSccR7k53reUkavnDgG7yaHP7+XCyf46Uw/qqB/pSDScrh7wC8L45eEL0AuqPldnzEffS76Nfx0/N4PYl7HsfrIfx9zSQZnmMyP4xjdLA82PT30MUyLOtvjHFpx1NTJXstr/y7zR39WfS6mNgzeK2F7mqMPYvmiV6CxLZea37zAC8HQYEwvN+Hztdb/9aE/i0C1gdHdMZre/RCT/jeTlwQELOuhfPi8LICPQR9yz89Mcd/8t4Qi56Y2GG834PeLSviOTo4yoMHDyQuLs4sZpDz5KQk/YzvTWDblJQUfX1Ec0N/G30znn0SYxhm4fz/UwR8D4M/jdfv0as96sL4+Hi5Gx1tkUiTuLm5iVNeJyVaWlqaxIKYSSAiCUjC3rhxQ987OjoqIXndIwhaHv0r9DPo/UBM5//tBGwDGhxHn4spBdmVt7x5lWhnL5zXnhd/V6hUSb+7cOmiNG/ZSrbv2iGuIOSVK1dk9fr18slnn0nkxYtSqVJl2fLbNgkIDJQ7t28r4e7dvSvnLl6Qc7hXbEyMEtfBwSHjY4tiTJPQScjO/xsJyAEuQl+F95XsXWCIXgy4qFixYtLtgw9kw/oNEnn5knw3daokJCTIg9RUORNxWgKDgqRcuXLi6uoqwcENpcNbb0lKaop0+eB9adCwoZyPjFRieXp6ytrQUNm2dZv07tVb3PG3If6ZtJIY43z0tRbu/C8T0LzQbZXrRN6yy3FOTnL//n0VPYrklWtXpXmLljJ95kwpWLCgdH77benSqZPkyZNHShb3lZ07dkhMTKzUrFVLXmrTxvIcB6lVvYbUrVtP1q/bIGfOR0qSKU2exjXBjYIlX758Muqr0RL+119Sr0EDuX79usTGxkokuJIizntnaK2xluEY93vi8F8kICzeRAxkeUbjwAEnQEw5iWvXr0nTF16QVWvXSv78+XW8v+/dK8nJybJ0yRLx8SkiS3/5RaqBQHfvRsu9uFj5ccECef8//5HR48bJ4AGDwKnrJWTRInH3cJcZ4NZ8eZ30OS1btdbXPr16KfH79+unnJmS8kD8SpSQ7t17yE0s3NlzZ1VVZBBtIpC5IOICh/8CAfPhwavx+pG9L5OSk8QZXOFdqBC4KUYeJCVLsxeayctt2yl02/fH73Lw4CGZPOVb6QgOXLliuezetQuGIY94QGxJQF/f4lLCz1e+mThe9u7eA/1XUS5cuCChGzeIp7uH+ILw1apXk5MnT0roli2y//AhCd2wQcK2/yYJ4Lp3u3SRH6ZNlYNHj0rt2nUk4uwZyeNod7rvYFC7VQ39SwT0QCc0ecnel6nQY1z1uSEh8tkXXyjBflm5XLZs3iojvxolHi6uEv8gWa5fuya3b9+R5555RnaG7ZRfV62QZ59/XlIfpMjhw4fl/PkLsn//Ab1nRMRpfV3+y6+SjPvfvntH3uzYEXqyrPTp2UvKwahMnzpNggKDJBlqomLZctK7T2+ZO3uOREVFyd59f0jNp2tKFNRHJq0Beji6/z9LQAfxw79HQZUK6WQB4kGRpFW9igEn4H2pUqWlabNm4uKcT5wh0sMGD1ILPGDgIP3NmtWrpVAhb7kJsV28bJk4OznL9atXJb+Li3h5eUnbl16SLp07Sym/EhJx+rQ0fe55Wbl8uZTy9ZO80KuJiYlqpX9duVLWw5DE3I+R8OPH9N4LoRoSAX26wug0adoEvz8j88DVcVAr1MN2m0ndysMW1zL7JMmBL+xGYGpxp9I1YrWSJUtKT+iiTRs3ypKflsnHw4arYi9TOgBiDCMSfUcOHTos1SF2fsWLi3NeZ+ndr6+cpghC9C5cuSzFCvuoYeEkb928KY4gfCFvb0kmx16/oYR1d3cXE76/A+xIqPMiCN0VFt3bu5BUqVxRXnn5FVm4eJG0bt5S1m8K1fHt2rlLKlWuLL5FikixokUlT95HOmAJYJSK8IUvPBEONP0dADiQkXg0FneBw4jFCFNavfgiuGmpfPbpZzJvzhyJjr4rNWvXVmPinCevjIBIk4h+xf0k+s5tcOMAmTN7tnJvUGl/JQ6tJtWAFwhXoEABwJdU1Y3FQXQaIT4nDZaL3yUB+kydPk3q1Hxa6qITX9apV8+M5N/vKvVgtb8Z97U0BBT6euxYSYJxyYJ4bC6YKwMUXo/NgQa+z2sSLmXzjID4MkSIolqggKccO2YWn48GDpQRI0fg73ApWrSILFywUAYOGijlAgIVo1GMPEAoFxiLVBBDLMCXXEexJBFI0BQS0pRmRUt5QERConwgoht+6+TsbHX3SHASnqqEz2j83LMyBoQrU8aM5SdOmCjDhwyRouBA43eGJ3P+/HlxBycXwwLxHjbtSKqDVM+SgAFZEBCiOxlwpa8pA7Y7c+YMCFRULkMxTxw/QQaASMUhgldv3ZSagCQhPy6UyhCbrVu2Qhc2lUAQmkQi0UgEczjMBC6Nljv37+nffkWLia+fn1VUie8M4hJoE0/eunVLLl+6JNFQC0R3RYsUVfeP9yJR6Dufhzoo4OYh9erXkzt37sDiH1DRdYP15vN5XVJSolyCvn6n49ty9uxZvaZUyVLK4TY6/xeI8mtiEwZ7iIBBmRDQEhZrjjehpgxiS6DKz06BiHSpWjVvLhUrV5IT4cd1ALfxGSf+QbducgPXbt++XbmGnylGBDEuXY3S+1UqV16eefZZiFmwVK1WTfGbEs/ZyY7fnCD37t2Vs2cw4QMHZAdA966wMLkOdeACbEjiO1qgCrmZ6oVcyQUxOI7P50Jcw0L37PGhfD/1B7l9J1oKw6AVBIGLgEvJ0daYoYO8j5c5mXJgYOYc6A3OO2+BLemcf+qgQ0eOigeArYenhyxbslTavPwyMJyLKnMPDw8l5EVwgjtgix8mloZBJUNEzsN1c82XX158sbW0hM5s0bKlcod14bAyhh60tZicOLuTU3oddgTjCAXQXgegvnPPbnGBNS+BRSCxMgYZSMybME7k+BnTpst/uneTvr37qLXmor/84kviBSNGCUsXGHaQsrjTGYecEBAXrwSbvfyQiQL3cGAr1qyWKlWqytq1a6RZsxekfJky0qVrV+nz0UdSp0YNpQQhicF1lyB28QDYL7ZsLUOGD4WPG2y9531AEBLLThAgc/WC+zuBWG5uLvo3F3X+3HkyacIEuHQnpGihwmrRbUWS+tENi/7VV2Ok/euvKVe2wNipB08Ca77XqbMsXLhA/Es/RJMD4MRaObHCz2ckHlE8OYMcSL1VD9buZ+C3119/HZZunJQsVUrGfj1Olv/8s8TA6hKrcYDkpFPwAkoA5qxcsVLWrF+rxIuLS4CI3YNI3ldi5IR4hvGgy8bf8z5cgC5du8g+6LKRI0bqZ+p9YPGMe1Mf1oB+fv3NN2TQgIFSACL7y4oVErp5M3RjmkRGRooT0AKZxDG911ITvaspuxwI0Y2y5Cas4kMoQuJVqVoVeu0GiBKh302Z/K307ttH348eNVo++fQTKQ3w6wLuu3fvnly9eUPaw4WbNXeOckQS3Drex9HxyYciSUQvr4L6Pmx7mPwH+PD0mQhgUX+19lQjVwDWJ0yaJN17dJdKFSpIyMIfJSAwQBoFN5I70NcFMMaEhESIex6FTTZqJAVcSHZPSacW7Kx7B1vicfWSEpMk6sZ1CZkfIp06d4IeuSWvAMDugU/bB2DYBbqvQIGCSrwSsKQMQzH6chsKfwzEZeiwoXov4kIS7p8gngFNyHl8bfxsYzkafkzaQK9t2rJZgoACKBWF4Z/36t1LF/hUhJkJXnu1vbqLTvjdC9DJH/bsKW+0b6+GyNnZ2ZZWjG6PzNQKWwDzdbBqEVvFSxHs3/cjmTB5ovTt00cGDx4C5X1EWsMQVC5fQaHFfXBbYR8ftaA3wXW3YQFnzZylCjo1NU0t3z9FuKy4sWOHjrJ46WKFUjQQlIw4SFSn997T6M3qVasUm14EMggHkggMCoTXUlSRQ34L5LLQJxX/FAJ97j2EAy2wpTvEd5rtQGi1qtWoLjt27ZJvvv5GBg8ZLGtXr5XWL7VWotDh7wA9SKNBEaWok1tJvPdBPIoDVzIr4qViwt6WCWenkZsziT7bBDZwT2/zPdu90k5WrFohZQMC8BtHTRMQJTjhPVECA7sfdushP0yfChVUUi5GXZaCbu7wgHzVlbQaLwcZD6Ee5GBPB4J458Scm7W2KOiMZs2ayYJFi9SIbN2yRarXeFpmz5wh/v6lZfOmzRIWth2iUVhXneH1USNGyceffqzKODExGcRzyNIgkNN3YZGIMckNmaU5GB6rWKmi1KxZU9/nhBPr1qot+w7slwplyv7tdZg4xygJfuYZFXW2BSELxKdwYfkFBvFn9CKQLNshgAs9TXYIWBUEPPJQ3hNW6UrUFY3tfTN+vFowigAHcwoK2sOC8zjjkxD1l1q1ltXr1uZIbElAT+DJQQMHyfgJ48XVOZ+Y0uxTMCElWapUrCR/AEg7A2zHxsZlm4jnzp2TBvCPExLi1YMhQojEgn8Nt2/g4EEadKBqIqj39fWVbVu3giu7Ka61xYYgYBuMbk06EXY0R2ffszc5WuFr4MR78XES3KChLAF8KVHCD+IQqLqPlus6jAYfdBADKFLEx2owstvoT584cVIawf1iVo6GKbN441WMZcOmTeoi0mhkBwKZVMUUkDWr1kibV9pIQImSGu25AY+EkWuO/csvPteKhHzwuzl2H3gl9JMTLVlBGwLugBg3VoRC5M0IBLhvoSVJbXcF3SBW3gW95Oixo7LyVwZIN8u1a9fMfi0GR9doLoBs7Tq1Man7WYqtPeexePFisv/PP+XAoQNSCB6Nkb607RT1W3ejpSKMV6NnGqmKyAmErPxUZfkLhmI3EEQRiKmnh6fsgKsZunmTlPD1Ex+oIvrW7Eb5h50FKg1dOA+v93Sa4JPnNIyTxQqylwkMgtjEyPZt23Qy7ExHNgaOav9ae4tuMeXYaiYCKrE1B4xIszwvs3HkB4du/+031ZOuri7ZBt40aGyjxowRb8AuSg/HS/UUCKxIMTX8ZZ2bk9Oj4oBNHCzVA6R0/exOlCJEdi9arJg5sZ38AAjTJMM+/tgcXIVOyqlXITarXL9BA/EBpyclJmZ6LR3+Pbt3yx9/7FM9mEWlQjqcSJRQtmwZeatjR40c2XoqOUxINrISEM9vkqusHB58+eoVaQl/snmL5uplPA7WS8ZilC9fHrCphtwEtsxMNhnmik1MkHVr16QjfnZaSoo50vIO/F43qJ+E+IRcjRU0a6EETDOXkdXJ7aSZDG/eqpU10PA4jS4eXajmLVpIUmpKpo46dXI+oIO9u3ebQ8guLjladKqLOnVra1r0yrWoXHEgvTXwfSVyYG2xlP/ltDG6UbxwEWlhIWAuB/JQ48Qoxo9akMIwAOHHjsFy/6VinJNm3LctfPRH6dtstPokYLXc/ppi1iC4oZQvV9ZqBHKqAtTaWQivfjfUQOWnKpkrDOAFZZq4ANddv31LNoWGWo1LTnxmtupP15DiPkUkMZeSQ9rxThVyS8AUU5pO1IgA50yHmMtUycVG6Zotd9SqXVsepKVmqlN5tTPwGjN6ORVjwxgGBgZKmbJl1THInSKUCo4Yt39ufssB0GOoWrVqrsSXERvCiM8//VQtI/+2vc9zzzcRt3z5NceRmRZnTub3PXtl374/YVicc6hvEyR//nzyVJUqEpuUmEv6iQ+Xt1hufkyOY5UVS81y06i3WMHw/Xffycm/0uuxBykp0qBhA4DyOuopZNYYKbkXHyu/weXKqRgbcb6yUD+P0TxJQK/cErAQFDlBaG5CTWws4UjFOu7duzcdAeJi44HPHBVUs8ohM+7mfWj9Duzfb4U3OW1+fiXE2cEx84qFRzc3EjBX5a/MNdAA5MegDWyV3ebiYo6xbVi3Tl8PWgjwd+zNTMjGjRuLe34XgPXkzEF1YR/Zs2uXnIk4a71vThqTYPnSR55zNBUSMFeF5iyvoOuTB3gspzCAhPrrr5Pqg3pC95EAJ0+eVp1k6EFOqErValKxYkXNwWTW3OEVXblxXTasX5djMVZd7OaqBDRSmTkOgufKcc1ioPyORoERFnudbevmzZrPZViJLtVGizU1rqH1dXd3lVfatZP7CfGZijGflRfXhobmzhprwOIx8Cu5L82ehTXCWJkRihMkl6QByuRxSI/D6YifBIc9SHmgOVrez7gPv2MAYNfOnfidg64egwPr1q3VfAuvY/jICD+xCtXT1c1aumGPgIygHD5wUCIizqifmxNIRZ87CSrCNnSfE3XOETEi6Wl8wpoXDiDq+jWdHMPaHp6etskVc6bOUixO/eRimzcAUTiYO9G3pUe37hJx6pRUqFBBJ2/kfjlpVg34lyyl70nkE+Hh0giYkmqB1xkLxAg1S9/4/Mz0FLmdpXV//P67EtD4fXYaMWAy05gFC9qNPmVxnyR+G22LbBiS79e/v4bXu3bpIuUw+Xg8gAO8eOGCNS7HCfHhjDrbSgAfqgU+MABr1q6V55o0kfCTf8mx8GNaVMm6lsuXL5vvY6ldJlF5P8YXL168qEQLB0GPnjgur7/5ppb7XonK3Gc1PmeFQk6tMceUmJpiIZQ5tcAk2QXQgbqX1f+EW5lEbWL5q+u2zgkJcAaiwLK02XPmyE4C1QMHtAK03WuvKdfRApPLrkdd1YoDe2LFiHRQmSDNMzAZlRdiysS2Qh9vbx2QwVEGx7CGxQdWlWUWJO7IL0fIlO+/k7btX5V4gN3MOJDPKwYxplFiZWt2Y4RsTKabrJF3R51PterVZX7IQhk/ebLMmzsf7mqwnDl31h4BY6g/L9p+EljKXxYuCJFCHgW0BHfWjBny3ZQp0q1Hd1n60zJwSj5N5pBjbsfck5MnTjxkVIxIMonIEBXL2/bu26fcHIGBZFKrrCVs57HiAUFBEgYd+clnn5rHBLBetVJlLMDtR1rjS9euakF6dqyxofPCj4WrS8jGBWaB08Rvp2AhIjVcdur0Sfl+2jTp1Kmzji0DEW9xJifTpxdTVSfFJSfK+rXrpAYc7latWmpC5l3chGVhxH9G27dvn9U42DM05Nj792OlRo3qmhHrjHtcirpid1KXoi5rZOfwkSNamsbtDqybKVy4kDRp1kzuwuV7lE7i1Bgpz44Y0/W7dOmKnIJ6KWjRf0wVvNGhg6xasUI+/fwzCdu6TcaMHSu9enwo/4E+L13aP52BAi0jHLFORzKie3JYOTjZLHmgS8U8aoM6dSVk4QKFCYZB8fbwlF1hO7By0emImlE/mUxpSggq+/LUqZlYSX7Ogk9is7g4cz2zIbasfs1v2QKWmRgXLuAlhw8d0nLgR4FqgztPHA9XnevmZvbDmUyKBKMEP9NIY5F3Yu7r5xGnTyljcWNPmg1exF0OkYD7Mt6c9SzLl6/QTSzNmjTVLQqJiQlSPqhMOleMZbjHweKbQjeqIUlLy1xsmLa8ceOmzJs1GxMtqBzL1eRmGHMgNa/4FPQG16+FMblunZRhtRvAQnOrVzTELNNnAPachor4bdtvjxRjY+PNxtBQDdzSGdAIqa+vhMybpxnI/QcPyZDBg6Vvn7663Yw4lVW4Lpagh4WAf1AgqFgO2XIMY2QTx4+X4HoNZMu2raqg78OyssTjAibMKk9bq7R58yZrgOBRK84C9NORZ9WQ8D4s5X2387vK4VTmXt5eEhF5TvOx6XxjcCMNQ42aT2tqNStrvHGDWQ862UkK8Z4sP4mCAVzx668auDWew+upG99/7z1ZtHCh1K9fX5o2bSqzYQfGjR0jfiCwzbPvgHZHHS2yvMV2ECzgXrZkiVk/uHvoznOuxo8LFkqXru/LVZh+QhjqI5b1rlm1Ss6ePadcY89SGhNhKpSNC+GNRVm4eLHMmT9PC9OZpCL3mAmwwbIgzla/WzN2zVs8krP4eREvb9WDFy5csnJxRk1JGixZtFiLPb0siICLyTpBEpBqZAoscNu2beXlNi/JD999p+W/RtbOcpuNFEZHyy73venyHNAzZOdUrhas27aw7TJm3Dh5/a23ZMbsWVqqRvxHESTIvhl9R76BsrWddEagGxefIGGAGWztXmkrh48e1UQU43JaSQV99AZrbMS8h+TSxctWOGL2jU3SFKqkcrkKai0zaxwPa6T37tn9ELF5D6oSRr0XhMzXXVFGcTsDud9PnSrVa9RQKXgAvc1K2qCAQClVunQ61WVpO0yWpBJ9OSqN1IzuXPT9ezJ1+nRNRrdt87K4gjgfdu8h73TqJJ3ffVfBLa/zgz87f/58OX78hF0u5Ir/GBIi5y9dlBFffim/rlguPpbqBa48X2kJly5bJpMnTdYC8h9hsDLmX1ie8Xyzpvo9lXmqnW4o+T2WhJPtRkMmrJjwnzhhgi5Y8aLm1CyBe4+ePaVsuXKyZ+9eLTxfGLJAWsNwcTOPPZWBGW7TWbK0gz3I3//noNL+JqP7FS1mKupVyMS2ZPESZdQCrm4m86KaTFu3bNX3vLZcYBDPbTC1fKGFfpeclGyCZTbdvXvPBChiio2NNfXt3ce0dMlS8/fJD6zfG51/gzP0+xXLV5iGDhliguXW3/N7EFm/W7t2nT7X2cHR5Oqcz27Xsbq5mwCq9Tf8/e3b0fo+MvK8yS1/flMR70KmMv4BJv8SJU0waqZt237TOTdv9oIpLGyHaeDAgaZdO3ebWuBvuLMmW9qg7zfoZltc1MDBvOnOyoGXgdeOEGhC9hm59dFq9zwyG5aKGbEvv/xC/Ir7WleF7t6Y0WNk6PChqviNraYUU64+t3YR2xnBCns6jHqVYsaaF5agubr+zdEsMGfyihsTeQ8721jTcWydunV1gw5FlBBEg7RNm8nmrVukbGCQNcjB/S4zgQ4iAZ6564DxSZZ+DB44GNivtPTs3VM3Atmo0bexSov0bYbytqtGiJ8TZFVWzZq1tPr92NFweSa4obhjQveg/2jJXF1crG4QJ07Dcgvewi64f/UBhI36Z06UwDYneWMqc4q3LbFJSOJQI26YdfrSvHFHA7/4Deuix0+cIGX9A1Sv6IYeGCg+gwXxs+bOlQoVK8q40aNlx+5dMnbMOJk29QfZGRaGxbdG3pMhbvmNMGCegrZRCAdxwlCbGn8WhDVmMdG5c5EaeebKc2JcUaL2BHAZDUgKOIWWm4NginAJrOurr7YXXz9f5RjjsIicRrwzFp8bu5LImdnpDx6kKMEJqmfNmCXDPh4uJYoVt0R8UiU2Jk7rX0hgVtWqG4hncqcTa6aJLlatWqnJK6uUOOhxBmusY8qw0cYZXHjbZAnzG5x1AeadSLxs2XK6fdTTs4AMHjpEd2OeOROhTj83vgTBh+VvTuKzIKzyJogK/djcbGN43KbcCivOhV+44Efp1PkdxXyELWyETBx3cKNG0rpFCw1wMDR3AxJUzKeocix3ntKtFQuYtxzg4wv6WPfNZnQsyZ7DbHUSV5xbFLgnjl4AV29t6Hrp1ae33IPLR0u1c+8eza+ympWcwwrQs9AnwfUbyvHw46rTHhXPe9KNxZ202CTelG+nKPEKwfthAoxzImjnzoHOAMzc/EN1xPEx8FEUuJYcq+iCG3ZsoBBo860t8cQGxli7yXxUSaw9lH/t9i3p3bev5oJfh4jWq1tHnOGCpUBUtkFPaIAVA2KvEFRWd2TWrV1b5s2dp5iOkyIWe4xSiizTDJQY1kXzEYRcffv1hfHz1hJkLi5z0BUqVZS+H/WXV9u1kz27dstKuI88+OLriRN1nhy/XS9G5JOM9DLK26zdZKZ018wGSct2H5b05+W/qheSAq6a8M03+uASfn6qA6l/KPK0YAxdcQNM75691LJ6eRXQFU97gkQ0osdMAXD72YH9B6RxcLBMmzFdSgElMM7IyVGCGAn3hs89ZNBA+XP/n5p/Ibd1/7A71E2AfDRggHUfX7pnOMhwjDg2I70eIqBFS/2EN7vshYtYi+KJQbZu0VKTQSzznTNrljSC38iAAA/P0cMmIM68nsl3HgjBTX3cxTlr5kyFNF6YrJFgyi1HakIJzyTh2Fn6OwCcFYyx0BPhFltjZyjdx1LQ98w1HweI5kZvQpPp4LxGjYLh+VxSDmU+Ju/DezPP4ZMx9miVxztDLsDmp1sdMxwq4QaLxlB/5aeqyIhRI2HaC8tKOOTUH1TAFwF7enzYU909nuVy7OQJKejhqQdQFIIYXcPKcov+dnxHnEbd6uNTWC07lTbhjm0Cyp4aIcHIwbyev2MAgxzHHVOD+veX9RtDNcnEhaPy57jOXrygxeWMR9KiTps5w7xznXv44Pa92Kq1zJ49Ww4dOqQbs5lrNuKOFsPRjLovR5sNLT/uCKv8o8km28Z8ASf/NdwhTuiTYUOlCFy5M/AfG9RvINvg7zoCsObF4NpDx6xasVJF2TaTdwkuHQ+HgAejcb7nmzTRwkrut8tOcpyR8ksXL2plA8NfW7dulTv3IJpAByx74zMM6ESOatmqlcyD77tm9Rrp0a2bVrjexjyo56Lxu5YtWklp/9Ly7aSJgDTu6lZa88Qwqpj/2ExplNWZCcD6i0HEDrZEpLGgnmDxT0BAgEYxuFEm3lKkQ8J+/tln8gX83i8//0JGjPhS/GHFDVxnrC6TNtwOxpA6txX441605qVASBKCnOaAa0kI3eN79ZqG2k+fOqXJKZa3kSt84dNyV1FqBitPD4PFmqvWrNaNjm3btVViN2jQ0LpQVSpUgr97WYPIXEDbXA2P1Es1H9cnuSagEs18XsLTJjs6iGg+Ji5WlixdJtWrV9dIyU3oRjrkr7RtqzhpQUiIEp2GhUMr5lNEXSsSxrzrMkXBOSfBRbAulliOAzClWSMdDH26u3so+KV3Yxvip4EgdOFhFOQgju1ezH1ZvHiJJoZOnz6lC94SRC2NBWXVw2zoZN7LTqrgUpqDVDLZQSQ5IqBlC5ino3kX00OVRPR/+/XuK5OmTJYB/QfIRIgBXboL5y9K1WpVxB1cynMK2rZ7FdChH5T7Ho0tknOojzLzUDJumM4qz8tSk3zQ0XGWvImxQZubHrl4UXilL06QTL9+J1y1bdt+k5YvvCC+xYtZo9IW1WVKdZAyaWbj8ejajixLH8xEvI83PE/lIWeW4sNN1998/bVMgJ85dsxYPeul+wcfqNtEoMqE0Jz5c+ESnpW33nkb+jJSxZTcSgJGWk5yu3L5sjVIYD3eLjnZmovmd0x5UnyN09/oX1MnMw54ADqRR6AwUGpcT2NBkaxfp46GzY6EH1XiUbU0b9pEFzFvXqeMkKW2KRvEyxYBbVkavaGYzzL9O4AJPcVjTwYPGSL9+vSVIXDxmMnas+93FY1kiG3+fGZ9M3vmLCkJolKUGLCNT4hX3dajx4cSMm++KnuKoXFeIKu+Ei0FliQGlT7dxbbt28t38DCGDx2mxDYvwgUtxuwHKWDyKTHevLOegY8AuJVMp36M62kgur7XRb6AXqa1ZVVFBqvPgu8D2SVK+mBCVpQ2yTVw4lL0TmLZmGNESDxByI1bNsvvu/cqYGXSnZMrCn23c9dO3fE4e+4cSYGb9Ta4MAagmoGG0WPGyJcjR0gS3Kj+AwdoUDNk/jyJiY3TY+8mf/+9phkjYDyawlqvDd2g7mMhHx954803pFTpAFm06EdJgO6MPHtWOr7TEQt0Wt3LaKgSrwIFFBUUApg+Ag5lnpvVYKVLlgJGzGfrXpKKPEo0TByyX3GVm00d52m8xCabx0HQOhOW7N65Q1YD63FhzgN/ffL55xqJHjV6tAwfNlw3ZT/f+Fkt700EUV9tr6eKyCsvt5HWALncusBtXonJSVKmTBmpXq2qGaDjGdRnxJyfDP9YqsOdZGCD+V3WUgeBIMt++VmrKj4FAqhUqZKsWbVa/oqIAETx1227xI0E+fRxHRwdbIl3FkRjrfKfOa5vy6X3FAU9wUNfF2cMPDA5xI3XFCuesjbthx/UiBCydOjQQXUidR93OzEc+twzjbQcg4EI7nqfMHmSxhmNoCgnqffK7yLhR4/JUXTuOD8WHm61xrVq1NSsIdtQGCgaiePHj8tz0HEz4c6xXIP35ELwuRm8n1DM5WkxHz6Wq/K23PugDtIR1nknhjLN3vf0Bhjm4vZUYkIm6ocMGqwH3XAXZEu4g8yzBgT4S7f3P5DFS5coDhw56u9d9Q9SUjV2x1gjY488h4Z7e8sAjtwBGOZJILPnzpXqNarpkXjcrLgc3hG9k+++/VZioGdpzDx5jNTDFv9jcN5Xj0ODxzsG2Xyw1nRhVs8kE/DaJGN2j9aWRqZHzw/N7qBzPnXhKN6u0JvLfv5JN23vCAvT7xMBOf4uv8hvOYDHwRyTw7ujR47oNlcmtlpaNvgsA+GdoG+Ns7c6vPa6HhtVDAihmGVPXwbi7cfteIzcdpNJ5HFOsXxShxgcwSCaoveSDIdgay01JkbHnWcW8IwqfsatpSxHY1CCtS/9Bw6UUSNGyozp08Xfr4Sl/NbNIm5mkaPHQkLTUvft1w+YL0Y3eH87caKUxG/oibCqiycY8ewX49QNG3HlyWyfotdW4j2BiTvk9ih44xh1O0fBM8TSFx8OEfOZzpkGBthZc8iJk3uo4OnSceI8pIw+NIlx+OBBJTpLyRiCZ3EnMeP9+DitsKcLZvjZj5CVSRj3eLEERJ/UUfD/BAENAF4MC98PbzuKnTMHM+Y5WC5iHNZjPpXISQMXPFeVbpdRjEmMGA+DQe50cspyjxyl4SeMZRKIdOafOEv/nySg8Z8RMEjYFn++awGp/0ajQg3BIH5iwew/+Z8R/BsEtP1fFsriJRh/NxLzmQOBT4hgl3mOAe67A8/hsfPH/r/+bw4Rlj7P8t9hELzWUmBuknJiPvDHy6I7XW3ma7L44QR73Bl4E1+csvx3GPvx/rAp+3N+ou1/BBgAYiYw8UEO8CcAAAAASUVORK5CYII=" alt="Reviewed By Accessible360"/></a>
		  </div>
		  <div class="footer-col-3">        
			<div class="footer-social">
			  <h3 class="footer-social-title">Follow us:</h3>
			  <ul>
				<li>
				  <a class="footer-social-facebook" rel="nofollow noopener" href="https://www.facebook.com/FindLawConsumers" target="_blank"><span class="footer-social-icon fa fa-facebook" aria-hidden="true"></span>Facebook</a>
				</li>
				<li>
				  <a class="footer-social-youtube" rel="nofollow noopener" href="https://www.youtube.com/watch?v=WQiNbzazOhw" target="_blank"><span class="footer-social-icon fa fa-youtube-play" aria-hidden="true"></span>YouTube</a>
				</li>
				<li>
				  <a class="footer-social-twitter" rel="nofollow noopener" href="https://twitter.com/findlawconsumer" target="_blank"><span class="footer-social-icon fa fa-twitter" aria-hidden="true"></span>Twitter</a>
				</li>
				<li>
				  <a class="footer-social-pinterest" rel="nofollow noopener" href="https://pinterest.com/findlawconsumer/" target="_blank"><span class="footer-social-icon fa fa-pinterest" aria-hidden="true"></span>Pinterest</a>
				</li>
			  </ul>
			</div>
		  </div>
		</div>
	  </div>
	  
	  
    



    <script type="application/ld+json">
  {
  "@context": "https://schema.org",
  "@type":"Organization",
  "name": "FindLaw",
  "@id":"https://www.findlaw.com/",
  "logo": {
    "@type": "ImageObject",
    "url": "https://www.findlawimages.com/latl/findlaw.png",
    "width": "288",
    "height": "81"
    },
  "url":"https://www.findlaw.com/",
  "contactPoint": [{
    "@type": "ContactPoint",
	"telephone": "+1-800-455-4565",
	"contactType": "customer support"
	},{
	"@type": "ContactPoint",
	"telephone": "+1-855-281-8859",
	"contactType": "sales"}
	],
	"sameAs":["https://www.facebook.com/FindLaw","https://www.facebook.com/FindLawConsumers","https://twitter.com/findlaw","https://twitter.com/findlawconsumer","https://en.wikipedia.org/wiki/FindLaw","https://www.youtube.com/channel/UCt8h4T88wCQwKB7kMt65C8g","https://www.youtube.com/user/FindLaw/about","https://www.pinterest.com/FindLaw_com/","https://www.youtube.com/findlawconsumers","https://www.instagram.com/findlaw_com/"]
  }
</script>








	  
	  <div class="footer-lower">
		<div class="row column"> 
		  <div class="logo-footer"><img class="logo" alt="FindLaw.com Logo" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHUAAAAYCAYAAADEbrI4AAAKQ2lDQ1BJQ0MgcHJvZmlsZQAAeNqdU3dYk/cWPt/3ZQ9WQtjwsZdsgQAiI6wIyBBZohCSAGGEEBJAxYWIClYUFRGcSFXEgtUKSJ2I4qAouGdBiohai1VcOO4f3Ke1fXrv7e371/u855zn/M55zw+AERImkeaiagA5UoU8Otgfj09IxMm9gAIVSOAEIBDmy8JnBcUAAPADeXh+dLA//AGvbwACAHDVLiQSx+H/g7pQJlcAIJEA4CIS5wsBkFIAyC5UyBQAyBgAsFOzZAoAlAAAbHl8QiIAqg0A7PRJPgUA2KmT3BcA2KIcqQgAjQEAmShHJAJAuwBgVYFSLALAwgCgrEAiLgTArgGAWbYyRwKAvQUAdo5YkA9AYACAmUIszAAgOAIAQx4TzQMgTAOgMNK/4KlfcIW4SAEAwMuVzZdL0jMUuJXQGnfy8ODiIeLCbLFCYRcpEGYJ5CKcl5sjE0jnA0zODAAAGvnRwf44P5Dn5uTh5mbnbO/0xaL+a/BvIj4h8d/+vIwCBAAQTs/v2l/l5dYDcMcBsHW/a6lbANpWAGjf+V0z2wmgWgrQevmLeTj8QB6eoVDIPB0cCgsL7SViob0w44s+/zPhb+CLfvb8QB7+23rwAHGaQJmtwKOD/XFhbnauUo7nywRCMW735yP+x4V//Y4p0eI0sVwsFYrxWIm4UCJNx3m5UpFEIcmV4hLpfzLxH5b9CZN3DQCshk/ATrYHtctswH7uAQKLDljSdgBAfvMtjBoLkQAQZzQyefcAAJO/+Y9AKwEAzZek4wAAvOgYXKiUF0zGCAAARKCBKrBBBwzBFKzADpzBHbzAFwJhBkRADCTAPBBCBuSAHAqhGJZBGVTAOtgEtbADGqARmuEQtMExOA3n4BJcgetwFwZgGJ7CGLyGCQRByAgTYSE6iBFijtgizggXmY4EImFINJKApCDpiBRRIsXIcqQCqUJqkV1II/ItchQ5jVxA+pDbyCAyivyKvEcxlIGyUQPUAnVAuagfGorGoHPRdDQPXYCWomvRGrQePYC2oqfRS+h1dAB9io5jgNExDmaM2WFcjIdFYIlYGibHFmPlWDVWjzVjHVg3dhUbwJ5h7wgkAouAE+wIXoQQwmyCkJBHWExYQ6gl7CO0EroIVwmDhDHCJyKTqE+0JXoS+cR4YjqxkFhGrCbuIR4hniVeJw4TX5NIJA7JkuROCiElkDJJC0lrSNtILaRTpD7SEGmcTCbrkG3J3uQIsoCsIJeRt5APkE+S+8nD5LcUOsWI4kwJoiRSpJQSSjVlP+UEpZ8yQpmgqlHNqZ7UCKqIOp9aSW2gdlAvU4epEzR1miXNmxZDy6Qto9XQmmlnafdoL+l0ugndgx5Fl9CX0mvoB+nn6YP0dwwNhg2Dx0hiKBlrGXsZpxi3GS+ZTKYF05eZyFQw1zIbmWeYD5hvVVgq9ip8FZHKEpU6lVaVfpXnqlRVc1U/1XmqC1SrVQ+rXlZ9pkZVs1DjqQnUFqvVqR1Vu6k2rs5Sd1KPUM9RX6O+X/2C+mMNsoaFRqCGSKNUY7fGGY0hFsYyZfFYQtZyVgPrLGuYTWJbsvnsTHYF+xt2L3tMU0NzqmasZpFmneZxzQEOxrHg8DnZnErOIc4NznstAy0/LbHWaq1mrX6tN9p62r7aYu1y7Rbt69rvdXCdQJ0snfU6bTr3dQm6NrpRuoW623XP6j7TY+t56Qn1yvUO6d3RR/Vt9KP1F+rv1u/RHzcwNAg2kBlsMThj8MyQY+hrmGm40fCE4agRy2i6kcRoo9FJoye4Ju6HZ+M1eBc+ZqxvHGKsNN5l3Gs8YWJpMtukxKTF5L4pzZRrmma60bTTdMzMyCzcrNisyeyOOdWca55hvtm82/yNhaVFnMVKizaLx5balnzLBZZNlvesmFY+VnlW9VbXrEnWXOss623WV2xQG1ebDJs6m8u2qK2brcR2m23fFOIUjynSKfVTbtox7PzsCuya7AbtOfZh9iX2bfbPHcwcEh3WO3Q7fHJ0dcx2bHC866ThNMOpxKnD6VdnG2ehc53zNRemS5DLEpd2lxdTbaeKp26fesuV5RruutK10/Wjm7ub3K3ZbdTdzD3Ffav7TS6bG8ldwz3vQfTw91jicczjnaebp8LzkOcvXnZeWV77vR5Ps5wmntYwbcjbxFvgvct7YDo+PWX6zukDPsY+Ap96n4e+pr4i3z2+I37Wfpl+B/ye+zv6y/2P+L/hefIW8U4FYAHBAeUBvYEagbMDawMfBJkEpQc1BY0FuwYvDD4VQgwJDVkfcpNvwBfyG/ljM9xnLJrRFcoInRVaG/owzCZMHtYRjobPCN8Qfm+m+UzpzLYIiOBHbIi4H2kZmRf5fRQpKjKqLupRtFN0cXT3LNas5Fn7Z72O8Y+pjLk722q2cnZnrGpsUmxj7Ju4gLiquIF4h/hF8ZcSdBMkCe2J5MTYxD2J43MC52yaM5zkmlSWdGOu5dyiuRfm6c7Lnnc8WTVZkHw4hZgSl7I/5YMgQlAvGE/lp25NHRPyhJuFT0W+oo2iUbG3uEo8kuadVpX2ON07fUP6aIZPRnXGMwlPUit5kRmSuSPzTVZE1t6sz9lx2S05lJyUnKNSDWmWtCvXMLcot09mKyuTDeR55m3KG5OHyvfkI/lz89sVbIVM0aO0Uq5QDhZML6greFsYW3i4SL1IWtQz32b+6vkjC4IWfL2QsFC4sLPYuHhZ8eAiv0W7FiOLUxd3LjFdUrpkeGnw0n3LaMuylv1Q4lhSVfJqedzyjlKD0qWlQyuCVzSVqZTJy26u9Fq5YxVhlWRV72qX1VtWfyoXlV+scKyorviwRrjm4ldOX9V89Xlt2treSrfK7etI66Trbqz3Wb+vSr1qQdXQhvANrRvxjeUbX21K3nShemr1js20zcrNAzVhNe1bzLas2/KhNqP2ep1/XctW/a2rt77ZJtrWv913e/MOgx0VO97vlOy8tSt4V2u9RX31btLugt2PGmIbur/mft24R3dPxZ6Pe6V7B/ZF7+tqdG9s3K+/v7IJbVI2jR5IOnDlm4Bv2pvtmne1cFoqDsJB5cEn36Z8e+NQ6KHOw9zDzd+Zf7f1COtIeSvSOr91rC2jbaA9ob3v6IyjnR1eHUe+t/9+7zHjY3XHNY9XnqCdKD3x+eSCk+OnZKeenU4/PdSZ3Hn3TPyZa11RXb1nQ8+ePxd07ky3X/fJ897nj13wvHD0Ivdi2yW3S609rj1HfnD94UivW2/rZffL7Vc8rnT0Tes70e/Tf/pqwNVz1/jXLl2feb3vxuwbt24m3Ry4Jbr1+Hb27Rd3Cu5M3F16j3iv/L7a/eoH+g/qf7T+sWXAbeD4YMBgz8NZD+8OCYee/pT/04fh0kfMR9UjRiONj50fHxsNGr3yZM6T4aeypxPPyn5W/3nrc6vn3/3i+0vPWPzY8Av5i8+/rnmp83Lvq6mvOscjxx+8znk98ab8rc7bfe+477rfx70fmSj8QP5Q89H6Y8en0E/3Pud8/vwv94Tz+4A5JREAAAAZdEVYdFNvZnR3YXJlAEFkb2JlIEltYWdlUmVhZHlxyWU8AAAL4UlEQVR42txaC7BWVRVe678X771cuCFi8orn8DBfPOKRITLN+HbKUSfTahzTRpuiJKXIphktbexl2NA4ZdGMOtg4TqD0IAxBDCS6kAQiIMJAiYgIBsrlPlff2nudc/Y5//kf9zLq0JnZ/36cvdfZa6/32j/LfNpIRKOJWIjREhRXa0Pb7NuuJhtzM46h/3UMPoF3X0X/dvR7480itOehdFDeE8FKDYWfZtRin+ac5eLHo/1l3xM9huoqzOlE/TOUuzF3IOpHUc7H4g5Muh3t31LFJ+cb9m2hAjpdbt86JrYfhwf7A/LzKMHla130fjy1KP1QmmJqciUiiO5a6yaMN6B9GjpfxrzRbrHQbKDyO4w1U4jQe/AIR/wVnLlIH1SNRvTetmNsgT8U9TFST//HTy3QPW7tThzEs+hvRbuOYtnJSC05riywrhN5Ef0aTDsWSHQnDrrzg0OJWx1v4cEe20x6FIH2gC07qoJ00hI1UWOtOIWHgciSKvHRhR2qYHB4D6H9AyxrQD0fZdP7jYgE6piFYvVXpDqrZY2TWlITlVuA6oKR4PYewFmIQ/0jiAsJp73l7Od7Jp+5g1y8Dzm5CVYlUcXMKffI+EUSgfoNypOO8s9pZteVkQ51Y53ax3pnMogOW21ocKxGOE+5mAmpIPbV7kPtdwMltupd50B+0ESNkZdurgwQR2saYHxSpR3lXyhL7dV5KFfa+BaUxTZ+BdZfggMebcTRg9hl71eV+epklE+hnEPO8RG1mXvx/b/i+0+R2lAx94nzJDaqpKdqV/E42/CagDLUHE3vChMdBOTtqFegrLEl+u5ifHUaPegEZyn2uLGESTgb7y4DjFPY+zqL7VxSnrQ9euaXGxfrma10qMHDruWsZxuiJmk3PuvNSuJAXYy537MlapOXGoQLMOleY5yn8fsnCzFmOw81Voee0QH3BjTuQXNBzoHegnIX5oyM1Gns+YrgHf8KvTvQO5obBuXg0c2nBmUuyk0oY1lpGKj3lIYQug0fVD/jfszrcEwofLc5mR82xu8wbz38xhfRmxPgpd7693MYQLXDHLy/zoi9H/1nI8rVppH0MWK1SjhgiNZIjWOsJZjS5lWzm/cOqm+iO8/Wbcf8A1g0DIuGGyMNwNh9qLdGm7TnKsybj3eNZiYQI8tqciqfBwL+LCy/DWNH8K7Rc5sLHoOwOjkY7pnq1Rfj8X6sMYdql90YPQigSqDBKGd65qFBxuSvY+6vUf8F/e9ivC++Pgn9M1Bey8BvUulPHDzXmlli36eiTDVCvY7567IhTcjOndQzRo6yBQqmK5D1rkDwZ6BcC4LuQP0tlPWO6F79fs44shfmNoHTrw6I2l85HkAaTaD/iVqTB5s9M1EdGHEMxn8K2Cqp/y0yKEF0dgLOm+LyB6zVRMZjALLR7HmbQVc8JgD/e1FP9AkS+gbaj6P8G50NpMwnci5gfCRLVAA4B1I7zpj2XcxrNPM0FmVHZi8YlxGGZzO+9Wo2+RBxgqqXj6O0JEF6WVWk0vRSNtPCWY9TIkeMhilyQPpqzHkpA+8nmDcG829ONs39MVedp8sxf5yN7wOcOahXB2uPGYPc4g5QZKKdUleKeJzsUyqo4DIkX+wIS3S8xPt92Ct4TBah9CPdt8iZGN9gNk81Sm/s7Vy014UfQ3UedjUY9THsbwHg3Il5g/BiBvo7MppxRsCZf/eMnI1T/ftTAGQuFs7NEipppzD+oaUD08chmXYMw9X3pxgheTrNgbjZ9tLfVNUhjF0Rr2f6MxrPlTAF6qA8jJk/V7w4k7pLhTTcY++3M/G0JQ03YWS1l9tQpnsHis9wVs0zHjQhhIfdu0eUOWyPKiRTbV878LsQsD7rzZITtIUZml1g5/E2IG/IcmEhjYTk862TNslLMeZo4XTRTYvP8BzEJpdw6Ily6lDeSsa51vZWQPssr5JIc7brK2iQFZi5i23PnNG8CTpSvpxYRHHEZ+k4ORQPcLtjaD/8CfOaHYOp84ffKUaLv+F3D5as9UcoE/B+YMCIp6NMsfbLmLAxpo/RqDY4VJWW5QCkoUeD50ROGyVzUm1oVZohMkdocDmRsl2pWJSLJKIQ7EVMIprMKdDnEPa0OzzxyN8MskdqW/ZjYGyoNWKwRrBKkiqVPeSp3mlCvMwpHoBjqIcuw+OPJi7Lf4DiOnjDalPHeBPjvFZ9xmFn49hDWiXeV3gGa68HvLFKWPSXGczJog6lp49m7g7kS5uTJm4DAR5yatBSbUUGJlS/IsVxluRFR7Habokdp0ppO6/GxJIMDfatFiBxuILxU0Z4M6G1FJkCrpRcKE9wte13oVwISMPTZ8HpeFjSFySY3w7016PxJc/rotK6BgymGmk6k1PL+7Fui+1yrXnYTaDNFLSXGahZxpQtGFtLOeSpTWI+R8de3fILiwgq6dRcdKBe5RWyZOA8Vc+JFbTbgyiTwFXaviQRyDkcKVLGFSoroUNQFmHOJIpOi/gV4PVmlI8zpoI3TuNx8H1yLkNeRH+vSjLeX4iBH6F/Kt7NsDN63jlbsVPIzRiciTIF85ucalcb62G+5lR0pHmCs8jaxYKEHmy3c4acltBKjgeXO1z38oh5t/0tZOhXYX0NvjUgiWg4rXYpP6PE+QnF7Dl8BXAmWXbhFfzcYc5PeyZw0uTCb9A6P4d1t7pbMJHhlh1TQg3S7FDgyUbJk3cAYznmzwSEiQA8gr0WGmd4b+Mo25Rz9VYsOVVkXSSYxzn3sC5b5w6mq3LAX6x6IwCwwQx3XYaibsJHh6VUXpFWoJHukCRSG5IO3CMV3P2sUg2Y/RLDqMU8/6Ul7HE9K3NxbgJa1/4Dg5dZAkLDmKFQRw0eTxf6BGqPXrBskKYjNSQcgQ/0NTP2PPnwqYi5C+mcImdK+WxSVGIExEuBd7K6XHFjoXdWoUiiSgqxh+c3WA+A0yocvuafAyeFi6U5Vr9VJPaj+ZB+4NnfBg44jzMr6Rxbn/HmBJVS55BGOWRwNQafZTZ4M9rbMtphJyBuNYdTU66XauiJ6W+jPGMOXT/LQQ+JNG9tmnNP4FKKS8SAQhkHsSowIRzEpnytceSlzvPMD21Ujd2KOfWlY8/Yazla2YSmnlYvHY549YBVFyHHocnRjBiRxtoDypixFzRkIWUSoevI/SHBPRvQ358xKwfI282zNBvncgmeXrvR3iSekJ+2PHq7Jf+frg0Nea4rHxKKyxwEU/F/m6rxcotssmQvDJ5i73GO9upXHsTEeXYL0mGB+zTRiwLmSeyzK30iLZSbSPEpy/aKXCyih6jZnI3unphpFMZOx9iN2Eszpf9BodmfuQB5gzlMhTj8S9u3w5agmIj+SNtbq7PPxWd73HvB8JiZRwXMuQI6TaVyEsaPYuyjGNsJFAdGkioVL4/LeoyxgSsR2JS53MtTjUHmyoirSYlvozxhi6aT/gdKPUMf5+khT2ZVQSKPG7E+T5zDpcn3bvXZq8yNVBRbJ/N6Yd4jov/BIvqlU5XkQpCbLAmw1jk0au9ELhLNCmnyXv9wwHxR1t4F21kJefsMqS31+O7GNppLHPEmjO+zCwP3dyHR8EYvLvy+VUV/Acz+FsBvYtPBTWaX6yVRBd0L38RiSW/DGgMEGoID6lPEGekzrwk4ui7VJ3oSZTbm3web28Q+qX5lKowSWYJ1mMP3oFOwTfe279RQGjcws/3rI7rQUbGS7N2re9cXI72Az5OYqx7rnRjUS4RrsI9rMNYhVKhlr6UeJc3ZEj0QOHy9ckK4VejAu3V//4mSJjtLnO6r7qpOZLDt7Q32DN3iLxPkY6R/JRIeAiw007RSiTofHxiMwVas2dzDLMtq1pjLx73NAber7fuxeY87M+oqa3P2uMS+qhXhPXHaMLmm/AUWrAH8G1FP9w6CXpLzy4Ct6celXmpkBfnrP7HLam0cAcEWorUa89tS6tg0Q7H9c/jWWeK9zfb+Hcs9X896R+oZ9TCU3RbA+j3ay1G3ANgyS4K0kc9JZ89wDztz4dR5l7/k564SzK5h3QLA2Ub+BmyTU7n+eY588mKU2Xz3J4T/CTAA/ewIjkcnEIUAAAAASUVORK5CYII="/></div>
		  <div class="logo-footer-tr"><img alt="Thomson Reuters Logo" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOkAAAAlCAYAAACnHc4sAAAKQ2lDQ1BJQ0MgcHJvZmlsZQAAeNqdU3dYk/cWPt/3ZQ9WQtjwsZdsgQAiI6wIyBBZohCSAGGEEBJAxYWIClYUFRGcSFXEgtUKSJ2I4qAouGdBiohai1VcOO4f3Ke1fXrv7e371/u855zn/M55zw+AERImkeaiagA5UoU8Otgfj09IxMm9gAIVSOAEIBDmy8JnBcUAAPADeXh+dLA//AGvbwACAHDVLiQSx+H/g7pQJlcAIJEA4CIS5wsBkFIAyC5UyBQAyBgAsFOzZAoAlAAAbHl8QiIAqg0A7PRJPgUA2KmT3BcA2KIcqQgAjQEAmShHJAJAuwBgVYFSLALAwgCgrEAiLgTArgGAWbYyRwKAvQUAdo5YkA9AYACAmUIszAAgOAIAQx4TzQMgTAOgMNK/4KlfcIW4SAEAwMuVzZdL0jMUuJXQGnfy8ODiIeLCbLFCYRcpEGYJ5CKcl5sjE0jnA0zODAAAGvnRwf44P5Dn5uTh5mbnbO/0xaL+a/BvIj4h8d/+vIwCBAAQTs/v2l/l5dYDcMcBsHW/a6lbANpWAGjf+V0z2wmgWgrQevmLeTj8QB6eoVDIPB0cCgsL7SViob0w44s+/zPhb+CLfvb8QB7+23rwAHGaQJmtwKOD/XFhbnauUo7nywRCMW735yP+x4V//Y4p0eI0sVwsFYrxWIm4UCJNx3m5UpFEIcmV4hLpfzLxH5b9CZN3DQCshk/ATrYHtctswH7uAQKLDljSdgBAfvMtjBoLkQAQZzQyefcAAJO/+Y9AKwEAzZek4wAAvOgYXKiUF0zGCAAARKCBKrBBBwzBFKzADpzBHbzAFwJhBkRADCTAPBBCBuSAHAqhGJZBGVTAOtgEtbADGqARmuEQtMExOA3n4BJcgetwFwZgGJ7CGLyGCQRByAgTYSE6iBFijtgizggXmY4EImFINJKApCDpiBRRIsXIcqQCqUJqkV1II/ItchQ5jVxA+pDbyCAyivyKvEcxlIGyUQPUAnVAuagfGorGoHPRdDQPXYCWomvRGrQePYC2oqfRS+h1dAB9io5jgNExDmaM2WFcjIdFYIlYGibHFmPlWDVWjzVjHVg3dhUbwJ5h7wgkAouAE+wIXoQQwmyCkJBHWExYQ6gl7CO0EroIVwmDhDHCJyKTqE+0JXoS+cR4YjqxkFhGrCbuIR4hniVeJw4TX5NIJA7JkuROCiElkDJJC0lrSNtILaRTpD7SEGmcTCbrkG3J3uQIsoCsIJeRt5APkE+S+8nD5LcUOsWI4kwJoiRSpJQSSjVlP+UEpZ8yQpmgqlHNqZ7UCKqIOp9aSW2gdlAvU4epEzR1miXNmxZDy6Qto9XQmmlnafdoL+l0ugndgx5Fl9CX0mvoB+nn6YP0dwwNhg2Dx0hiKBlrGXsZpxi3GS+ZTKYF05eZyFQw1zIbmWeYD5hvVVgq9ip8FZHKEpU6lVaVfpXnqlRVc1U/1XmqC1SrVQ+rXlZ9pkZVs1DjqQnUFqvVqR1Vu6k2rs5Sd1KPUM9RX6O+X/2C+mMNsoaFRqCGSKNUY7fGGY0hFsYyZfFYQtZyVgPrLGuYTWJbsvnsTHYF+xt2L3tMU0NzqmasZpFmneZxzQEOxrHg8DnZnErOIc4NznstAy0/LbHWaq1mrX6tN9p62r7aYu1y7Rbt69rvdXCdQJ0snfU6bTr3dQm6NrpRuoW623XP6j7TY+t56Qn1yvUO6d3RR/Vt9KP1F+rv1u/RHzcwNAg2kBlsMThj8MyQY+hrmGm40fCE4agRy2i6kcRoo9FJoye4Ju6HZ+M1eBc+ZqxvHGKsNN5l3Gs8YWJpMtukxKTF5L4pzZRrmma60bTTdMzMyCzcrNisyeyOOdWca55hvtm82/yNhaVFnMVKizaLx5balnzLBZZNlvesmFY+VnlW9VbXrEnWXOss623WV2xQG1ebDJs6m8u2qK2brcR2m23fFOIUjynSKfVTbtox7PzsCuya7AbtOfZh9iX2bfbPHcwcEh3WO3Q7fHJ0dcx2bHC866ThNMOpxKnD6VdnG2ehc53zNRemS5DLEpd2lxdTbaeKp26fesuV5RruutK10/Wjm7ub3K3ZbdTdzD3Ffav7TS6bG8ldwz3vQfTw91jicczjnaebp8LzkOcvXnZeWV77vR5Ps5wmntYwbcjbxFvgvct7YDo+PWX6zukDPsY+Ap96n4e+pr4i3z2+I37Wfpl+B/ye+zv6y/2P+L/hefIW8U4FYAHBAeUBvYEagbMDawMfBJkEpQc1BY0FuwYvDD4VQgwJDVkfcpNvwBfyG/ljM9xnLJrRFcoInRVaG/owzCZMHtYRjobPCN8Qfm+m+UzpzLYIiOBHbIi4H2kZmRf5fRQpKjKqLupRtFN0cXT3LNas5Fn7Z72O8Y+pjLk722q2cnZnrGpsUmxj7Ju4gLiquIF4h/hF8ZcSdBMkCe2J5MTYxD2J43MC52yaM5zkmlSWdGOu5dyiuRfm6c7Lnnc8WTVZkHw4hZgSl7I/5YMgQlAvGE/lp25NHRPyhJuFT0W+oo2iUbG3uEo8kuadVpX2ON07fUP6aIZPRnXGMwlPUit5kRmSuSPzTVZE1t6sz9lx2S05lJyUnKNSDWmWtCvXMLcot09mKyuTDeR55m3KG5OHyvfkI/lz89sVbIVM0aO0Uq5QDhZML6greFsYW3i4SL1IWtQz32b+6vkjC4IWfL2QsFC4sLPYuHhZ8eAiv0W7FiOLUxd3LjFdUrpkeGnw0n3LaMuylv1Q4lhSVfJqedzyjlKD0qWlQyuCVzSVqZTJy26u9Fq5YxVhlWRV72qX1VtWfyoXlV+scKyorviwRrjm4ldOX9V89Xlt2treSrfK7etI66Trbqz3Wb+vSr1qQdXQhvANrRvxjeUbX21K3nShemr1js20zcrNAzVhNe1bzLas2/KhNqP2ep1/XctW/a2rt77ZJtrWv913e/MOgx0VO97vlOy8tSt4V2u9RX31btLugt2PGmIbur/mft24R3dPxZ6Pe6V7B/ZF7+tqdG9s3K+/v7IJbVI2jR5IOnDlm4Bv2pvtmne1cFoqDsJB5cEn36Z8e+NQ6KHOw9zDzd+Zf7f1COtIeSvSOr91rC2jbaA9ob3v6IyjnR1eHUe+t/9+7zHjY3XHNY9XnqCdKD3x+eSCk+OnZKeenU4/PdSZ3Hn3TPyZa11RXb1nQ8+ePxd07ky3X/fJ897nj13wvHD0Ivdi2yW3S609rj1HfnD94UivW2/rZffL7Vc8rnT0Tes70e/Tf/pqwNVz1/jXLl2feb3vxuwbt24m3Ry4Jbr1+Hb27Rd3Cu5M3F16j3iv/L7a/eoH+g/qf7T+sWXAbeD4YMBgz8NZD+8OCYee/pT/04fh0kfMR9UjRiONj50fHxsNGr3yZM6T4aeypxPPyn5W/3nrc6vn3/3i+0vPWPzY8Av5i8+/rnmp83Lvq6mvOscjxx+8znk98ab8rc7bfe+477rfx70fmSj8QP5Q89H6Y8en0E/3Pud8/vwv94Tz+4A5JREAAAAZdEVYdFNvZnR3YXJlAEFkb2JlIEltYWdlUmVhZHlxyWU8AAAUSUlEQVR42uxdB5gWxRmeuaMdcKInLQgSa4gUNUQlYiGiGBsaEWssoGIwdlRsCGJJABWNogTR2CPEJ4oajb0QS4xCPAVFLBwIHCdFuPOAa5P3m3nn/mHZ/f8DiUme249nbvffnZ2dnfner823izbGqJRSSul/l5qo6/I2OuiBq7WO/63s7z5a6TOwvQ5HVmH7PsodqDoZ27OUVlthO1Eqy2WhKMB1vo3gpll6aVzRv/5AqU690llLqVFR3ibU3RpIeRrba7QFmvoRfp+K3R/gVxXKFOy/p93JQ/H3GF63D8qbKL9KhzullP5TIHXA64C/RwKYR/HgQyjbYWcWSh3K7QJSXjEY5WBoTGhRvTvq7YsmjiC4U0oppU0yd7ND80aAcm+Abbwx+kWl6/rD6lxKG7QOx79xtqjeBdtymLql0KR74nhbmLMv8twU7C/Gsdn40QLHbsW2K8rlKHPSKUgppc0AKX3PfADqDGfOmvlamxew/0pQrQ+OC9imYfuaaFRcdjS2As5tsRUt28ZpVDVJQA3IdsL+cEqAGQ6kMf5pSiml1CBNWgMAXQlw7YXtbVZ3OjAdg80cAHlXHOmLcwLSK7BdLEDE9i4LUGNWAe3TWac5jt2M/SVoYQgA2hPbx3XG5K5LpyKllBoGUmhA80dsC1FEiz7AoqxWNKoC4OwNV3MF6j0IoD2o6/1TB2H8vtZpYwvrhwnA51EOQhmKMgHH7ydAL0E53QFYPZS1p3XKyYCUUmpkpM2YDUI5ZwIJU7l/A0A3SrtQTyEg+CFQKKD6iwOgVsrDUqmfYP8e/HoCivEGGLBHKBsNVo8EdRbQPJ6L0p2CYBlKAc4vpZ9aHa/T0UY7KPSzYUkXtElnLaVGRXlGmdAnfB2A+QhlAY48TfjuBHA1wf5J2J+pdX2MdhDKR8aY7XF+RwEqAL0HALoDfj+D36JFj3RN2PZn4G8ltk9RPpSj3Iedb3D/P6BUZzO8Ve+hKUBTatzmrgAV0PsMwNkdP1uhlDP4g2NqHMoVPpmBVwh06nDM4Fr4l/pA0ZYAbSkaegdgbSsgRrkU5YeoPxpXT0TlhTh/LvZLcew83O96lGU53dImzdLZSqlRg/RnKKNFq6GMQplPM1eCQSOxfYPasy19xyuUi85K2Rp1T8b2WdT9BjiGZrXJDDU0ayfwHqsA0FEW7Er9lj7sQEmQAKAl4nuSu4+cU98GwsCFlppvlfQMIlB+kMusV1YoWMHTksJnHcqimLpiprdHWcNr4mgntiHP+KWqX5baiDrSrF+Isj5L33ZkWyUx50U67cqxlzpl7NeaJOtI2UQTe2+xXD5BWZ1Qd7tAIC+N6ZfMZVOUrzheSSST04Fj10LZlQH7vIt4bRJ153NJn2t5zQrHd2ot67RD2QZlOcrKhDHeiq7TavJCa5Wcw6bpVi1UGc0g99hZuIy/5XwF2ywL6km7nXi/AuJnnXPlEnnAX7ercqsd6zl/pZyfkHqw7nyOgwMpdeMdYlC6p5IsPn0CdgYDRnLBeE3/EyBbh93PhUF0/fOqC1HG4PwdNHHfxnHxa8/BFTJBn6NWR7T9BhVxi2C05EhnlLvo4+5vXELEkyFGZSh0h25JAyCZTHcHv6s5qPmRwNhICozjUSR1cQnKnjEMfBXKBSjvoPSLnJPsqVtQ9ibzKgq2aShj2aYnYZb3XDDOmvjHJ/R/NPtWQ+H2VnBuBMrZBF1IwjhTKFBDOoXBuD1UJlFF5uAxZde8bV89dXNzZZltGa9ZFZwXhppJBj4O5a8J/RcASUbZDuHckkTYPsNnnBccb+viFepgFZ9QI+N5IvfvQfkFeeusmLrTOR8yL1eTd/YKzldluMjyhKKA605hIFlz4wn2KK0jD/yD/ZS29wvArIL2RMGcT8CGAuFGzsv2wfFaglR47UEK4lMpGNZwvGVuii1IGdb5EH97E7AfsaEr8budUXkPo04NtF1ngKwU++dppx2eZkOyLjoA2+dceqCV3GXUIN+g7r64plDbAdJgcnMzwQ2tYZ5yEliLxO2CbSUkweINHt/LQ52YHFXJwQ4lazMeL1WZJCevnQs4yIUqfgmqZXA+pEEc0JYUAgt4vQiZc8hwRwTMWEigyv0lA0ui269E2pTzFwXM3S44J5N2cyAIysgorQigHpG2ziZwPXMtZl870+UQEA4MNFQbaj5FBhpJCynUyK3Zt2y+RoFzZ2y95QR6HX9LMFAE/gEoAwLeOo+/a6k1aoN5yotYCYWcj9YJ9/fnW/H38oAf8qj5PJBW8z4VFOby/LdT0JQFmtoHXryG98e68F6rWb+Wz9+V8RcRpocEFpEIpyu5v4zz2JR9FeG9C8/thvIpSk+OyxTycTE1qR2bc1xCgsbNzQyOF26mW2sb0LGBIdGgwwAaieIWwRc9kkkLN6Fe3/oseKV7cpJe1W4gBmjHNNAyppUzrc0YJ3n1qZSQ+6IcBs0r2uvDjaZBhqJyZRKTPCoR5wDOL9F8f4QA8APszc26oNU4kyg8r4JBfIQTJFrjXPrqeZS002gCjyVT+naqAwa/NAakxxEsKnLPvAAwz7qou2UgzUluGWln3wCgz9G6WcR7D6cLIULkGmqb8Dk9SQaYLJW9GtOfXK8/VJFZR3AsvObqQWHuhZHXhH25/bNyS311MTMe3a9NuH9t5HmO5b2lD0Uos6m5b6LFqFl3LYXHNvwtAmxWTPvVMfuTlH2xxN6jKTX5NILuKgrt9pxzb6mOpqLIC4C6PnBpJPvuKLo+KwNhKheIGWtkkGU99EnjQr1tXUOmxBgtZq6YcZdh+5q1UbUqQTWRGkcnM7n5PWreSsBLYsQspzF1qWN2PdNpJoM2rFl8DwSGBagEqOpLnnZK9Ak8d9m8pEn6lpqzkmajN3P8sW+D4yFzVcS0VxVz7GACdD0ZrZjtVtCc88tWh3Ds4mg/SuLQ1xyexW/yQFxMi6CK96+gFC+LmPyKftEp1E7rqD3G0SRU9PsLYkzSdbznhBxaMxetYx/92L+L8kFg4kZjIctYvzpSvsuC+PqAH8oDAbMu4IW1gRXg1w8WxfSjOss9qnhe2nxN2eXHeoGuCEQ/ll/QwqhiP8o5p6sCLT+AMZ4xBHuX0KTpj+kRRpO0v8H0G1+nL7OT1kbAUmdNL20nvw/Kx9SSX2eJ1TzBDp3ABzmIUmKBmwQjgaY51NDbMiAFv1WP3aipfNxt5VzoXFic5aW5Jik0m1QOM+0UarPBLIOCQY6apZ6pFiT4Rd4/2yXSlyr6pmKWXR+cE5PvxzKWNNGigufJwIx9nD5tYcKz9AqsiFUx5x/jtktEUCgC2kv83uq7va20PsEcVTFC0rsmPWjm+dKL47glKD9ivmfjmT0jfenFYI/OoV09dQrcL0UQvsT936HcS986zsX6JHCfmlKIvB9KtLszjGUEgC9j+xi05o4AzNdUy/+SG0reLcTSfONU9/LwGTUFVjQPV2d8QclmGm+cqfAujg8zmRGQd1LJHHp/tDE98F8yemfZHKVfvQWGyYQtMYFiZt7XwLrNAi0bx2yrI9FmFfFtbqY56oMUXwTmrPy+NkYDj6X2/SmFxyBeN4m+8fKIwFEJAFVBwKhJpH8+kCdW1MU02S+jC1K9GWPajwKmhj7kz2kKqpDpAjohcA9CkoDYDd/jKkdTWkRRWsWob9TX2pPxhxpGeg+jqaoCjVpLt+hFtjGU5X2av9NDk5aBSt+X6ugSTItMpNY0B3Baart2aYJAis25XUU4it86b0OpWce8Inm724QsWpwJ4tro38namkAaxfTSLlr6IM3f0PVpkbi4UL50S01MDf3K2hitWRRjGoegS9LeSctcs+nTDqfW+phBomL6nOMSGOQA+kqnEKw7Mop5AQE/s4H9yNW/CvpS0xj1vTShT7nooiAOEAqIFyhc4p6xNKavZd/zUqShAKyK9GNFgi/sLa+QKgi8UPAvYHxkEC2hPWit3M85HMz7ZtXSsrjxa/TxTpQCTlSZaFKYvT3ow0jk90Bdn95nWgKHQ6BlR0HjVXk96vk48vWGye4eBs68focA8NL+Ehw7HefexHYc6vfVzsSYluDA02Dba0tNzAqCIKp95GWC38QA2ptPeQmmc+iXxYFkKkE6JGjvcd4/P6GPazke0xiJHMz+daU03ouTuj6ITKuEiLUKAiZxlsJ0aoQz6BcVk/HabsKYPkf3pQ01ZDMGh4Yl1J9Os18ljHeuoFVDzjeEqhmd/SwmvhLnH79DjdiKGrUdl2nOjKkrFs8fWDqSB8RS+AmDWSfm6lye8w11Dy6B/JFaRAa4O4DTm/VOo30NSaDXAIcX4VxRNgnNsM/F7k0aWw330GAmXWtcdOpydx/9KbxeYdT9yXzDYgdGjrQCr+125JaUoNVkiLDUJkh8muwqLjfxwACgJQkg+SBYnmlCsNwXE8hRWUxWWTOcyN/d3PJVvcRWlNpxc3IQtytV/KK7v+ZqMlVTru+12MTxnMy1wtO4tKHIhN0S7lcVM/41CWPfOcEK6JDD1G9I/MLPXbQfSQGspyhchgTPuR/dhWxUyiivjzf8NIuADkGq6exqUccDtU3Rk2QGfYF2r6H54EV/gOtwfu9INN7f4hx8alDY7GY2gxDzKFFn1JsIWtZNdRElKQajTt4zHUqJZDXzRv/kG0cFP4QH0HFLgjSvgabh8wR0ITXi7rxWnutwLl8o+h9fJQQwaiOBo7sZuW2exWfuGAFKM7oNHrQ+On1vEFl8iD6Q1/Dnc0lA0ddcnWU8JIp/ZxCM2tTBDjX59bSICilcWsSYdNs2oE2fRNEneA7v+98UBMJe2Iz5XxvMz6YEq8I5u4cauDldkZDacSkmjJhvHQQiv25IJNtHmuB/mMvpVw5XRk82uBa6cACOzAbwBLAwhcxtWpJ1lSnG78OdmWXGMRr8HB3jcpwvwfndAeh3nUdqkxwkxPy1BbFR1wF1omVlyWImzv/NRdTMSk7G/Fg4VcyFvFwI2fnjhkT08nMAMz8BkHHX/4smyu8YIDiCga0WjAB6rTA+4r/mR4A/jWZVB5VJl4yrJzSCQZylNM0rOen+4WcEAaGXySAj6L/+kn5vUQDqz2nGRoVRfoy5P4RWjcoxltH+h0KvnH7X36llzgoEgEQzD6bQ3ilYAvIJBOJrXxmMmc+imsy+reA4+GebSnMzGz/ECeTPKTzzGfApifCJpmCYk6WtMo67zMfRjBU8FAjiwyiMV5JHtg/G9tGGmOtNmFjfPzNrph8ANFlbf8kMIjOK7zMb9ustjNiNxXVPAlw7U4u0w76kRU3llwC3RRGp/qV2EyGdfKvef9WyriQJ+AZOs+6EbU/evQjXdY8FKeNluiZn0LFcZdYT46iS58sTIrUVPB/NjR1HyTeM0b1egUYTkNxFhgz9qgqajlXBsZNi/K9yAj4MXHxB07NrwIyKmvrlmOjnpbzfQGp676osohC9JaJFwzW7ukik+nya4oXUeityBODK+ZxRf/xNmoaH0qqayjp3EnSShLFPgkYP+yl+8ki6FWH9z2g6XpPQtzqOSSu1cZ6sH8trKEy6RgSTv3frwPf1vFUZY/6Kq3gyhfnzBK+Au6/acFlOkb+fZQApt01eN8YC5yg3gGYNzd7ZbGhnZhG1d1LELOXnTt7wfhiula8Ggnk1JIW5gJJpkv8sCqD3NixkqT9Su6jSPk7Km9UmI4lvFXPXuGyXX8UCzH/W85xipTr1zPZMHWgqlqkNc1XDIE9nlZxg34ZtCLMuS7iHRFnDBPvSBAnelc9XkiAQ/PN3oUkUTWRvSXOpI/e/VdkT5r2U34UmlU+wX5NgRXVVmRTCKPnEdWHKhSp7wrpPl/sqJjAlAOnEel9Gope7MTDls4B8gv2ShADX1rRcWlKAfaayJ/77lwSa8RkrE+q1VZkEexMI2FIKZhNE/gtp3ZTHzPcOFFYlwb1a87r2bF94cm6Ofm/4EJmXvu2rZeiYpulhBExXoHd/BhAfdTcwNzn1rS8EADtoGyDQI1wk0LQPQudQ+Voylu6TvF084nrAUz77WURAC5gnORDrpvIuqXYTucRki+HZb+9+iEfuoVJKqbFQYFtrSCYtjrxovX8q+yVAfQxAJFHdd90xq9LFlHpB26it+BXmNygnOc0r3961roUEmQ7jkmk5FKi1xY19B1XDdDbTsZ/nfDjxb63JvCRnb9PvlaXUuEFq6Sh5XYz+zBBGavvhmISKexgX/PF+040u8iYfKdMCvkKV+cqDOPfH1/ugjiSj4xCcn0UToo22WS66m/NrdbOEuK77Jws6YoQU/yWdtZQaFeWP7rdh0AVQED9hqZFIrvsC4KfOptaf4vdkF2mzkV2JXD3gfAM916YSuhC/DUL4jzgAXEMcKKGRDcxinVfJFMIqbYFtbfYp9Ftz05oVSu89FOKlSTp7KTUKinL6PICtv9dooP0Anu7YPZuYE7/xatqdf3IveZrjUORVqHkE+CcAeC8lSznanEuz1uDcLBc3MnbRV7s0OVliGGlM+knPlFJqKEhDB1DANQW4kvWozvg9CsCTwI4kfhcAdLJ2KMkIxwKzj0FlSsRRlln6aLd+WsvlmHudO2mBXaRtEoSWiN9aXr9pANXpf1SRUqMHqQeB5PhIfqKsear3qVk7AWuSSVLDarLI/Cecn6td2FrS0nyi8rkEZp52C9YL7JcX3Lt38G+tGZ1SSiltvia1CBsqASHtMoHk050wadXzxv6PaRaCkllUInjmcsrHGwLdglSSGeR9xonGGAH1QJi9ss5VkQ5/SinlplwvRsvCM9+lM7J++gbMzTn89u7RAKVk2PQiKuXNEZ/lMtF9pd7GZGVp5T0beLJfW6jPAkkppZS+oyaNUhn04qE6oyHlNTfJJZUorbxzKnmtE5yJrJoZSX4w9qsOM93aaEoppbQ5pI1JMwRSSun/2dxNKaWU/sv0bwEGAHguNpczPE/kAAAAAElFTkSuQmCC"/></div>
		</div>
		<div class="row column footer-copyright">
		   <div class="footer-copyright-text">Copyright &copy; 2020, Thomson Reuters. All rights reserved.</div>
		</div>
	  </div>

	  
    


	</footer>

		
		<div class="search-test-overlay-wrap">
			<ul class="tabs">
				<li class="tab-link current" data-tab="tab-1">Find a Lawyer</li>
				<li class="tab-link" data-tab="tab-2">Search Legal Resources</li>
			</ul>
			<div id="tab-1" class="tab-content current"><p class="law-header">Find a Lawyer</p></div>
			<div id="tab-2" class="tab-content"></div>
			<div class="more-header">More Options</div>
			<div class="more-links">
				<ul class="tabs-links one current">
					<li><a href="https://lawyers.findlaw.com/lawyer/lawyer_dir/search/jsp/name_search.jsp">Name
						Search</a></li>
					<li><a href="https://lawyers.findlaw.com/lawyer/practice.jsp">Browse Legal Issues</a></li>
					<li><a href="https://lawyers.findlaw.com/profile/profiles/lawfirm/a/1.html">Browse Law Firms</a></li>
					<li><a href="https://lawyers.findlaw.com/lawyer/lawyer_dir/search/jsp/help.jsp">Support</a></li>
				</ul>
				<ul class="tabs-links two">
					<li><a href="https://caselaw.findlaw.com/summary.html">Find Cases and Laws</a></li>
				</ul>
			</div>
		</div>
	 	

	<script>
        var opPageId = "fl\u002Dlatl\u002Dnew";
    </script>
	
		
    
    <script src="https://www.findlawimages.com/etc/designs/flcommon/flfe/javascript/flpublic.redesign.js"></script>


	
	
	<script src="https://maps.googleapis.com/maps/api/js?v=3.exp&key=AIzaSyATKVLwES42jMDEEbmvOydBWr53zZlfL4I&libraries=places"></script>
    <script id="gpt_script" src="https://www.googletagservices.com/tag/js/gpt.js" type="text/javascript"></script>
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
    
    






        
    
    


    


    </body>
</html>
